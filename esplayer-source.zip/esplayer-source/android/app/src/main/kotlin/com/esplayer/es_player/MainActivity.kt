package com.esplayer.es_player

import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.drm.DefaultDrmSessionManager
import androidx.media3.exoplayer.drm.FrameworkMediaDrm
import androidx.media3.exoplayer.drm.LocalMediaDrmCallback
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.SubtitleView
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.util.UUID

class MainActivity : FlutterActivity() {

    companion object {
        private const val CHANNEL = "com.esplayer.es_player/player"
        private val CLEARKEY_UUID = UUID.fromString("e2719d58-a985-b3c9-781a-b030af78d30e")
    }

    private var exoPlayer: ExoPlayer? = null
    private var playerContainer: FrameLayout? = null
    private var surfaceView: SurfaceView? = null
    private var subtitleView: SubtitleView? = null
    private var isVideoVisible = true
    private var trackSelector: DefaultTrackSelector? = null
    private var subtitlesEnabled     = true
    private var subtitleFontSize     = 18f
    private var subtitleColorIndex   = 1     // yellow
    private var subtitleOutlineIndex = 1     // outline
    private var subtitleBold         = false
    private var subtitleBottomOffset = 0.12f // fraction of screen height

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        // Make the window background transparent so the SurfaceView behind
        // Flutter's surface is visible through areas Flutter doesn't draw on.
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT))
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "play" -> {
                        val url = call.argument<String>("url")
                            ?: return@setMethodCallHandler result.error("NO_URL", "url required", null)
                        @Suppress("UNCHECKED_CAST")
                        val clearKeys = call.argument<Map<String, String>>("clearKeys") ?: emptyMap()
                        val userAgent = call.argument<String>("userAgent")
                        val referrer = call.argument<String>("referrer")
                        val showSubtitles     = call.argument<Boolean>("showSubtitles") ?: true
                        val fontSize          = call.argument<Double>("subtitleFontSize")?.toFloat() ?: 18f
                        val colorIndex        = call.argument<Int>("subtitleColorIndex") ?: 1
                        val outlineIndex      = call.argument<Int>("subtitleOutlineIndex") ?: 1
                        val bold              = call.argument<Boolean>("subtitleBold") ?: false
                        val bottomOffset      = call.argument<Double>("subtitleBottomOffset")?.toFloat() ?: 0.12f
                        subtitlesEnabled      = showSubtitles
                        subtitleFontSize      = fontSize
                        subtitleColorIndex    = colorIndex
                        subtitleOutlineIndex  = outlineIndex
                        subtitleBold          = bold
                        subtitleBottomOffset  = bottomOffset
                        try {
                            playStream(url, clearKeys, userAgent, referrer)
                            result.success(null)
                        } catch (e: Exception) {
                            result.error("PLAY_ERROR", e.message, null)
                        }
                    }
                    "stop" -> { stopPlayer(); result.success(null) }
                    "togglePlayPause" -> {
                        exoPlayer?.let { if (it.isPlaying) it.pause() else it.play() }
                        result.success(null)
                    }
                    "pauseIfPlaying" -> {
                        exoPlayer?.let { if (it.isPlaying) it.pause() }
                        result.success(null)
                    }
                    "setVisible" -> {
                        val visible = call.argument<Boolean>("visible") ?: true
                        isVideoVisible = visible
                        playerContainer?.visibility = if (visible) View.VISIBLE else View.GONE
                        result.success(null)
                    }
                    "reapplyAspectRatio" -> {
                        reapplyAspectRatio()
                        result.success(null)
                    }
                    "ensurePlaying" -> {
                        exoPlayer?.let { if (!it.isPlaying) it.play() }
                        result.success(null)
                    }
                    "setSubtitleVisible" -> {
                        val visible = call.argument<Boolean>("visible") ?: true
                        subtitleView?.post {
                            subtitleView?.visibility =
                                if (visible && subtitlesEnabled) View.VISIBLE else View.GONE
                        }
                        result.success(null)
                    }
                    "setSubtitles" -> {
                        val enabled = call.argument<Boolean>("enabled") ?: true
                        subtitlesEnabled = enabled
                        applySubtitlePreference(enabled)
                        result.success(null)
                    }
                    "setSubtitleStyle" -> {
                        call.argument<Double>("subtitleFontSize")?.toFloat()?.let    { subtitleFontSize     = it }
                        call.argument<Int>("subtitleColorIndex")?.let                { subtitleColorIndex   = it }
                        call.argument<Int>("subtitleOutlineIndex")?.let              { subtitleOutlineIndex = it }
                        call.argument<Boolean>("subtitleBold")?.let                  { subtitleBold         = it }
                        call.argument<Double>("subtitleBottomOffset")?.toFloat()?.let{ subtitleBottomOffset = it }
                        subtitleView?.post {
                            subtitleView?.let { applySubtitleStyle(it) }
                        }
                        result.success(null)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    @OptIn(UnstableApi::class)
    private fun playStream(
        url: String,
        clearKeys: Map<String, String>,
        userAgent: String?,
        referrer: String?
    ) {
        stopPlayer()

        val dataSourceFactory = DefaultHttpDataSource.Factory().apply {
            if (userAgent != null) setUserAgent(userAgent)
            if (referrer != null) setDefaultRequestProperties(mapOf("Referer" to referrer))
        }

        // Detect stream type from URL.
        // DASH always ends in .mpd. Progressive formats have known extensions.
        // Everything else (including bare URLs with no extension) is treated as
        // HLS — the most common format for IPTV streams.
        val isDash = url.contains(".mpd", ignoreCase = true)
        val isProgressive = !isDash && (
            url.contains(".ts",  ignoreCase = true) ||
            url.contains(".mp4", ignoreCase = true) ||
            url.contains(".mkv", ignoreCase = true) ||
            url.contains(".avi", ignoreCase = true)
        )
        val isHls = !isDash && !isProgressive   // default for unknown URLs

        val selector = DefaultTrackSelector(this).apply {
            setParameters(buildSubtitleParams(subtitlesEnabled).buildUpon()
                // Disable tunnelling — it routes through the hardware secure
                // decoder path which causes CryptoException on many devices
                // (especially API ≤ 29) when used with ClearKey.
                .setTunnelingEnabled(false)
                .build())
        }
        trackSelector = selector

        val player = if (clearKeys.isNotEmpty()) {
            val licenseJson = buildClearKeyJson(clearKeys)
            android.util.Log.d("ESPlayer", "ClearKey JSON: $licenseJson")

            val drmSessionManager = DefaultDrmSessionManager.Builder()
                .setUuidAndExoMediaDrmProvider(CLEARKEY_UUID, FrameworkMediaDrm.DEFAULT_PROVIDER)
                .setMultiSession(false)
                .build(LocalMediaDrmCallback(licenseJson.toByteArray(Charsets.UTF_8)))

            // ClearKey works with both DASH and HLS; pick the right factory
            val mediaSourceFactory = if (isDash)
                DashMediaSource.Factory(dataSourceFactory)
                    .setDrmSessionManagerProvider { drmSessionManager }
            else
                HlsMediaSource.Factory(dataSourceFactory)
                    .setDrmSessionManagerProvider { drmSessionManager }

            ExoPlayer.Builder(this)
                .setTrackSelector(selector)
                .setMediaSourceFactory(mediaSourceFactory)
                .build()
        } else if (isDash) {
            ExoPlayer.Builder(this)
                .setTrackSelector(selector)
                .setMediaSourceFactory(DashMediaSource.Factory(dataSourceFactory))
                .build()
        } else if (isHls) {
            ExoPlayer.Builder(this)
                .setTrackSelector(selector)
                .setMediaSourceFactory(HlsMediaSource.Factory(dataSourceFactory))
                .build()
        } else {
            // Explicit progressive formats (.ts, .mp4, .mkv …)
            ExoPlayer.Builder(this)
                .setTrackSelector(selector)
                .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
                .build()
        }

        val sv = SurfaceView(this).apply {
            setZOrderMediaOverlay(false)
        }
        player.setVideoSurfaceView(sv)

        // Video container — behind Flutter at index 0
        val matchParent = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        val container = FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            addView(sv, matchParent)
        }

        val decorView = window.decorView as ViewGroup
        val flutterView = decorView.getChildAt(0)
        val parentView = flutterView?.parent as? ViewGroup ?: decorView

        // Insert video behind Flutter
        parentView.addView(container, 0, matchParent)

        // SubtitleView added LAST = above Flutter in z-order.
        // Flutter is opaque but SubtitleView sits on top so cues render
        // over the Flutter UI layer (including over the video area).
        val subView = SubtitleView(this).apply {
            val screenH  = resources.displayMetrics.heightPixels
            val marginPx = (screenH * subtitleBottomOffset).toInt()
            layoutParams = android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ).also {
                it.bottomMargin = marginPx
                it.gravity = android.view.Gravity.BOTTOM
            }
            setUserDefaultStyle()
            setUserDefaultTextSize()
            applySubtitleStyle(this)
            visibility = if (subtitlesEnabled) View.VISIBLE else View.GONE
        }
        subtitleView = subView
        // Add SubtitleView last = above Flutter. Uses its own LayoutParams (set above).
        parentView.addView(subView)

        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                android.util.Log.e("ESPlayer", "Error: ${error.message}", error)
            }
            override fun onPlaybackStateChanged(state: Int) {
                android.util.Log.d("ESPlayer", "State: ${
                    when(state) {
                        Player.STATE_IDLE -> "IDLE"
                        Player.STATE_BUFFERING -> "BUFFERING"
                        Player.STATE_READY -> "READY"
                        Player.STATE_ENDED -> "ENDED"
                        else -> "?"
                    }
                }")
            }
            override fun onVideoSizeChanged(videoSize: VideoSize) {
                android.util.Log.d("ESPlayer", "VIDEO SIZE: ${videoSize.width}x${videoSize.height}")
                if (videoSize.width <= 0 || videoSize.height <= 0) return
                layoutVideo(videoSize.width, videoSize.height, sv)
            }
            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                for (group in tracks.groups) {
                    val typeStr = when (group.type) {
                        androidx.media3.common.C.TRACK_TYPE_VIDEO -> "VIDEO"
                        androidx.media3.common.C.TRACK_TYPE_AUDIO -> "AUDIO"
                        androidx.media3.common.C.TRACK_TYPE_TEXT  -> "TEXT"
                        else -> "OTHER(${group.type})"
                    }
                    for (i in 0 until group.length) {
                        val fmt = group.getTrackFormat(i)
                        val selected = group.isTrackSelected(i)
                        android.util.Log.d("ESPlayer",
                            "Track [$typeStr] id=${fmt.id} lang=${fmt.language} " +
                            "mime=${fmt.sampleMimeType} selected=$selected")
                    }
                }
                // Force-select the best available subtitle track
                if (subtitlesEnabled) applySubtitleSelection(tracks)
            }
            @OptIn(UnstableApi::class)
            override fun onCues(cueGroup: androidx.media3.common.text.CueGroup) {
                android.util.Log.d("ESPlayer", "onCues: ${cueGroup.cues.size} cue(s)" +
                    if (cueGroup.cues.isNotEmpty()) " text='${cueGroup.cues[0].text}'" else "")
                subView.post { subView.setCues(cueGroup.cues) }
            }
        })

        player.setMediaItem(MediaItem.fromUri(Uri.parse(url)))
        player.prepare()
        player.playWhenReady = true

        exoPlayer = player
        playerContainer = container
        surfaceView = sv
    }

    private fun layoutVideo(videoW: Int, videoH: Int, sv: SurfaceView) {
        val dm = resources.displayMetrics
        val screenW = dm.widthPixels
        val screenH = dm.heightPixels
        val videoAspect = videoW.toFloat() / videoH.toFloat()
        val screenAspect = screenW.toFloat() / screenH.toFloat()
        val (w, h) = if (videoAspect > screenAspect)
            Pair(screenW, (screenW / videoAspect).toInt())
        else
            Pair((screenH * videoAspect).toInt(), screenH)
        val left = (screenW - w) / 2
        val top  = (screenH - h) / 2
        sv.post { sv.layout(left, top, left + w, top + h) }
    }

    private fun reapplyAspectRatio() {
        val player = exoPlayer ?: return
        val sv = surfaceView ?: return
        val vs = player.videoSize
        android.util.Log.d("ESPlayer", "reapplyAspectRatio: ${vs.width}x${vs.height}")
        if (vs.width > 0 && vs.height > 0) layoutVideo(vs.width, vs.height, sv)
    }

    private fun buildClearKeyJson(clearKeys: Map<String, String>): String {
        val keyObjects = clearKeys.entries.joinToString(",") { (kidHex, keyHex) ->
            """{"kty":"oct","k":"${hexToBase64Url(keyHex)}","kid":"${hexToBase64Url(kidHex)}"}"""
        }
        return """{"keys":[$keyObjects],"type":"temporary"}"""
    }

    private fun hexToBase64Url(hex: String): String {
        val bytes = ByteArray(hex.length / 2) { i ->
            hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
        return android.util.Base64.encodeToString(
            bytes,
            android.util.Base64.URL_SAFE or
            android.util.Base64.NO_PADDING or
            android.util.Base64.NO_WRAP
        )
    }

    // ── Subtitle helpers ──────────────────────────────────────────────────────

    /**
     * Called once tracks are known. Finds the best TEXT track (preferring
     * WebVTT over CEA-608) and force-selects it via TrackSelectionOverride,
     * or disables all text tracks if [subtitlesEnabled] is false.
     */
    @OptIn(UnstableApi::class)
    private fun applySubtitleSelection(tracks: androidx.media3.common.Tracks) {
        val selector = trackSelector ?: return
        val params   = selector.parameters.buildUpon()

        if (!subtitlesEnabled) {
            params.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            selector.setParameters(params)
            return
        }

        // Re-enable text type first
        params.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)

        // Find the best text track group: prefer text/vtt, fall back to any TEXT
        var bestGroup: androidx.media3.common.TrackGroup? = null
        var bestIndex = 0

        for (group in tracks.groups) {
            if (group.type != C.TRACK_TYPE_TEXT) continue
            for (i in 0 until group.length) {
                val fmt  = group.getTrackFormat(i)
                val mime = fmt.sampleMimeType ?: continue
                // Prefer WebVTT; accept anything text
                if (bestGroup == null || mime == androidx.media3.common.MimeTypes.TEXT_VTT) {
                    bestGroup = group.mediaTrackGroup
                    bestIndex = i
                    if (mime == androidx.media3.common.MimeTypes.TEXT_VTT) break
                }
            }
        }

        if (bestGroup != null) {
            android.util.Log.d("ESPlayer", "Force-selecting text track: ${bestGroup.getFormat(bestIndex).id}")
            params.setOverrideForType(
                androidx.media3.common.TrackSelectionOverride(bestGroup, bestIndex)
            )
        } else {
            android.util.Log.d("ESPlayer", "No text track found to select")
        }

        selector.setParameters(params)
    }

    @OptIn(UnstableApi::class)
    private fun buildSubtitleParams(enabled: Boolean): DefaultTrackSelector.Parameters {
        return DefaultTrackSelector.Parameters.getDefaults(this)
            .buildUpon()
            .apply {
                setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !enabled)
                if (enabled) setIgnoredTextSelectionFlags(0)
            }
            .build()
    }

    // ── Subtitle style ────────────────────────────────────────────────────────

    @OptIn(UnstableApi::class)
    private fun applySubtitleStyle(view: SubtitleView) {
        // Font size
        view.setFixedTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, subtitleFontSize)

        // Text color
        val color = when (subtitleColorIndex) {
            1 -> android.graphics.Color.YELLOW
            2 -> android.graphics.Color.CYAN
            3 -> android.graphics.Color.GREEN
            else -> android.graphics.Color.WHITE
        }

        // Outline / shadow style
        val style: CaptionStyleCompat? = when (subtitleOutlineIndex) {
            0 -> null  // no outline — handled below
            1 -> CaptionStyleCompat(
                    color,
                    android.graphics.Color.TRANSPARENT,
                    android.graphics.Color.TRANSPARENT,
                    CaptionStyleCompat.EDGE_TYPE_OUTLINE,
                    android.graphics.Color.BLACK,
                    null)
            else -> CaptionStyleCompat(
                    color,
                    android.graphics.Color.argb(160, 0, 0, 0),
                    android.graphics.Color.TRANSPARENT,
                    CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW,
                    android.graphics.Color.BLACK,
                    null)
        }

        if (style != null) {
            view.setStyle(style)
        } else {
            view.setStyle(CaptionStyleCompat(
                color,
                android.graphics.Color.TRANSPARENT,
                android.graphics.Color.TRANSPARENT,
                CaptionStyleCompat.EDGE_TYPE_NONE,
                android.graphics.Color.TRANSPARENT,
                null))
        }

        // Bold — wrap via a custom typeface
        val typeface = android.graphics.Typeface.create(
            android.graphics.Typeface.DEFAULT,
            if (subtitleBold) android.graphics.Typeface.BOLD
            else android.graphics.Typeface.NORMAL
        )
        view.setApplyEmbeddedStyles(false)
        // SubtitleView doesn't expose setTypeface directly; we use
        // setBottomPaddingFraction for positioning and rely on CaptionStyleCompat
        // typeface field for bold. Rebuild style with typeface:
        val boldStyle = CaptionStyleCompat(
            color,
            if (style != null) style.backgroundColor else android.graphics.Color.TRANSPARENT,
            android.graphics.Color.TRANSPARENT,
            if (style != null) style.edgeType else CaptionStyleCompat.EDGE_TYPE_NONE,
            if (style != null) style.edgeColor else android.graphics.Color.TRANSPARENT,
            typeface
        )
        view.setStyle(boldStyle)

        // Bottom offset — set bottom margin on the SubtitleView itself
        // so the entire view is pushed up from the screen bottom
        val lp = view.layoutParams as? android.widget.FrameLayout.LayoutParams
            ?: android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT)
        val screenH   = resources.displayMetrics.heightPixels
        val marginPx  = (screenH * subtitleBottomOffset).toInt()
        lp.bottomMargin = marginPx
        lp.gravity = android.view.Gravity.BOTTOM
        view.layoutParams = lp
        view.requestLayout()
    }

    @OptIn(UnstableApi::class)
    private fun applySubtitlePreference(enabled: Boolean) {
        trackSelector?.setParameters(buildSubtitleParams(enabled))
        subtitleView?.post {
            subtitleView?.visibility = if (enabled) View.VISIBLE else View.GONE
            if (enabled) subtitleView?.let { applySubtitleStyle(it) }
        }
    }

    private fun stopPlayer() {
        exoPlayer?.apply { stop(); release() }
        exoPlayer = null
        trackSelector = null
        subtitleView?.let { (it.parent as? ViewGroup)?.removeView(it) }
        subtitleView = null
        surfaceView = null
        playerContainer?.let { (it.parent as? ViewGroup)?.removeView(it) }
        playerContainer = null
    }

    override fun onResume() {
        super.onResume()
        playerContainer?.visibility = if (isVideoVisible) View.VISIBLE else View.GONE
        reapplyAspectRatio()
    }

    override fun onDestroy() { stopPlayer(); super.onDestroy() }
}
