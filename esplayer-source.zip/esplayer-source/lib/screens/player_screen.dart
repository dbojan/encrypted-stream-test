// 26-03-28-1711
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../models/channel.dart';
import '../models/iptv_playlist.dart';
import '../providers/providers.dart';
import '../widgets/channel_list.dart';
import 'settings_screen.dart';

const _kNext        = 'nextChannel';
const _kPrev        = 'prevChannel';
const _kSettings    = 'settings';
const _kChannelList = 'channelList';

class PlayerScreen extends ConsumerStatefulWidget {
  const PlayerScreen({super.key});
  @override
  ConsumerState<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends ConsumerState<PlayerScreen>
    with WidgetsBindingObserver {

  bool _showChannels    = false;
  bool _showIcons       = false;
  bool _showChannelName = false;
  bool _videoPaused     = false;
  bool _settingsOpen    = false;  // true while settings screen is pushed
  double? _dragStartY;
  double? _dragStartX;
  int     _dragPointerCount = 0;
  bool    _twoFingerDrag    = false;

  // Focus node passed into ChannelList so we can programmatically move
  // D-pad events into the list when it is visible.
  final FocusNode _channelListFocus = FocusNode();

  Timer?   _channelNameTimer;
  DateTime? _wentToBackground;

  final bool _isAndroid = Platform.isAndroid;
  final bool _isDesktop = Platform.isLinux || Platform.isWindows;

  // ── Number dialling ────────────────────────────────────────────────────────
  // User types digits; after a short pause we navigate.
  // "0" prefix → playlist number  ("00" or "001" etc.)
  // no prefix  → channel number
  String _dialBuffer = '';
  Timer? _dialTimer;
  static const _dialTimeout = Duration(milliseconds: 1500);

  // ── Playlist-change toast ─────────────────────────────────────────────────
  String? _playlistToast;
  Timer?  _playlistToastTimer;

  // ── Bottom bar focus (set by ChannelList D-pad Right navigation) ──────────
  int _bottomBarFocusIdx = -1;

  bool _isTv(double width) => _isAndroid && width >= 960;
  List<Channel> get _channels =>
      ref.watch(activePlaylistProvider)?.channels ?? [];

  bool get _tapTogglesVideo =>
      ref.read(tapSettingsProvider)['toggleVideo'] ?? true;
  bool get _tapPausesVideo =>
      ref.read(tapSettingsProvider)['pauseVideo'] ?? true;

  // ── Lifecycle ──────────────────────────────────────────────────────────────

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _ensureImmersive();
    _showChannelNameBriefly();
    // Apply subtitle style on startup (in case player is already running)
    WidgetsBinding.instance.addPostFrameCallback((_) => _applySubtitleStyle());
  }

  void _applySubtitleStyle() {
    if (!_isAndroid) return;
    final subStyle = ref.read(subtitleStyleProvider.notifier);
    final subBold  = ref.read(subtitleBoldProvider);
    ref.read(playerServiceProvider).setSubtitleStyle(
      fontSize:     subStyle.fontSize,
      colorIndex:   subStyle.colorIndex,
      outlineIndex: subStyle.outlineIndex,
      bold:         subBold,
      bottomOffset: subStyle.bottomOffset,
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _channelNameTimer?.cancel();
    _dialTimer?.cancel();
    _playlistToastTimer?.cancel();
    _channelListFocus.dispose();
    WakelockPlus.disable();
    super.dispose();
  }

  void _ensureImmersive() {
    if (_isAndroid) {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    }
  }

  @override
  void didChangeMetrics() {
    if (_isAndroid) {
      Future.delayed(const Duration(milliseconds: 300), () {
        if (!mounted) return;
        if (_settingsOpen || _showChannels || _showIcons) {
          // Keep video hidden while any overlay is active
          ref.read(playerServiceProvider).setVideoVisible(false);
        } else {
          ref.read(playerServiceProvider).reapplyAspectRatio();
        }
      });
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _wentToBackground = DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      _ensureImmersive();
      final bg = _wentToBackground;
      if (bg != null &&
          DateTime.now().difference(bg) > const Duration(minutes: 1)) {
        _refreshAndResume();
      }
    }
  }

  Future<void> _refreshAndResume() async {
    final svc = ref.read(playlistServiceProvider);
    final id  = svc.getActiveId();
    if (id == null) return;
    final playlists = ref.read(playlistsProvider);
    IptvPlaylist? p;
    try { p = playlists.firstWhere((x) => x.id == id); } catch (_) { return; }
    try { await ref.read(playlistsProvider.notifier).refresh(p); } catch (_) {}
    final ch = ref.read(currentChannelProvider);
    if (ch != null) await ref.read(playerServiceProvider).play(ch);
  }

  // ── Channel name ───────────────────────────────────────────────────────────

  void _showChannelNameBriefly() {
    _channelNameTimer?.cancel();
    if (mounted) setState(() => _showChannelName = true);
    final secs = ref.read(displaySettingsProvider.notifier).channelNameDuration;
    _channelNameTimer = Timer(Duration(seconds: secs), () {
      if (mounted) setState(() => _showChannelName = false);
    });
  }

  // ── Playlist toast ─────────────────────────────────────────────────────────

  void _showPlaylistToast(String name) {
    // Check if toast is enabled
    if (!(ref.read(playlistToastProvider.notifier).showToast)) return;
    _playlistToastTimer?.cancel();
    setState(() => _playlistToast = name);
    _playlistToastTimer = Timer(const Duration(seconds: 3), () {
      if (mounted) setState(() => _playlistToast = null);
    });
  }

  // ── Number dialling ────────────────────────────────────────────────────────

  void _handleDigit(int digit) {
    _dialTimer?.cancel();
    setState(() => _dialBuffer += digit.toString());
    _dialTimer = Timer(_dialTimeout, _commitDial);
  }

  Future<void> _commitDial() async {
    final buf = _dialBuffer;
    setState(() => _dialBuffer = '');
    if (buf.isEmpty) return;

    // Playlist mode: starts with "0" followed by the playlist number.
    // "0" alone → invalid. "01" → playlist 1, "012" → playlist 12.
    if (buf.startsWith('0')) {
      final num = int.tryParse(buf.substring(1));
      if (num == null || num < 1) return;
      _goToPlaylistNumber(num);
      return;
    }

    // Channel mode: "1" → channel 1, "23" → channel 23
    final num = int.tryParse(buf);
    if (num == null || num < 1) return;
    _goToChannelNumber(num);
  }

  void _goToChannelNumber(int number) {
    final channels = _channels;
    if (channels.isEmpty) return;
    final idx = number - 1; // 1-based
    if (idx < 0 || idx >= channels.length) return;
    _playChannel(channels[idx], idx);
  }

  /// Returns the channel to start playing when switching to [playlist],
  /// based on the "playlist switch start" setting:
  ///   'first' → always channel 0
  ///   'last'  → last-played channel id if still in list, else channel 0
  /// [playlist] is the newly switched-to playlist (passed directly to avoid
  /// stale provider reads). [playlistId] is its id for per-playlist prefs.
  (Channel, int)? _playlistStartChannel(IptvPlaylist playlist) {
    final channels = playlist.channels;
    if (channels.isEmpty) return null;
    final mode = ref.read(playlistSwitchStartProvider);
    if (mode == 'last') {
      // Look up the last-played channel for THIS specific playlist
      final lastId = ref.read(playlistServiceProvider)
          .getLastChannelId(playlistId: playlist.id);
      if (lastId != null) {
        final i = channels.indexWhere((c) => c.id == lastId);
        if (i >= 0) return (channels[i], i);
      }
    }
    return (channels[0], 0);
  }

  /// Called after every playlist switch.
  /// [playlist] must be passed directly — do NOT read from provider here
  /// because activePlaylistProvider may not have updated yet (Riverpod
  /// computes derived providers lazily; ref.read can return stale state
  /// immediately after setting activePlaylistIdProvider.notifier.state).
  Future<void> _afterPlaylistSwitch(IptvPlaylist playlist) async {
    debugPrint('[SWITCH] _afterPlaylistSwitch: playlist="${playlist.name}" '
        'id=${playlist.id} channels=${playlist.channels.length}');
    // Hide all overlays and resume surface cleanly
    if (_videoPaused) ref.read(playerServiceProvider).togglePlayPause();
    if (_isAndroid) {
      ref.read(playerServiceProvider).setSubtitleVisible(false);
      // Don't call setVideoVisible(true) here — it resets aspect ratio
      // before the new stream starts, causing stretched video.
      // The video surface remains visible; new stream updates it naturally.
    }
    if (mounted) setState(() {
      _showChannels      = false;
      _showIcons         = false;
      _videoPaused       = false;
      _bottomBarFocusIdx = -1;
    });

    // Use the playlist passed in — never read from provider here
    final start = _playlistStartChannel(playlist);
    debugPrint('[SWITCH] start channel: ${start?.$1.name ?? "null"} '
        'index=${start?.$2 ?? -1}');
    if (start != null) {
      final channel  = start.$1;
      final index    = start.$2;
      final showSubs = ref.read(subtitleSettingsProvider.notifier).showSubtitles;
      final subStyle = ref.read(subtitleStyleProvider.notifier);
      final subBold  = ref.read(subtitleBoldProvider);
      await ref.read(playerServiceProvider).play(
        channel,
        showSubtitles:        showSubs,
        subtitleFontSize:     subStyle.fontSize,
        subtitleColorIndex:   subStyle.colorIndex,
        subtitleOutlineIndex: subStyle.outlineIndex,
        subtitleBold:         subBold,
        subtitleBottomOffset: subStyle.bottomOffset,
      );
      ref.read(currentChannelProvider.notifier).state      = channel;
      ref.read(currentChannelIndexProvider.notifier).state = index;
      // Save last-played channel for this specific playlist
      await ref.read(playlistServiceProvider)
          .setLastChannelId(channel.id, playlistId: playlist.id);
      _showChannelNameBriefly();
      if (_isAndroid || Platform.isIOS) await WakelockPlus.enable();
      if (_isAndroid) {
        Future.delayed(const Duration(milliseconds: 200), () {
          if (mounted) ref.read(playerServiceProvider).reapplyAspectRatio();
        });
        ref.read(playerServiceProvider).setSubtitleVisible(true);
      }
    }
  }

  Future<void> _goToPlaylistNumber(int number) async {
    final playlists = ref.read(playlistsProvider);
    final idx = number - 1; // 1-based
    if (idx < 0 || idx >= playlists.length) return;
    var playlist = playlists[idx];
    playlist = await _getPlaylistWithChannels(playlist);
    await _switchPlaylist(playlist, announce: true);
    await _afterPlaylistSwitch(playlist);
  }

  // ── Control mapping ────────────────────────────────────────────────────────

  String _gestureFor(String action) =>
      ref.read(controlMappingProvider)[action] ?? 'down';

  bool _dpadMatches(LogicalKeyboardKey key, String dpad) {
    switch (dpad) {
      case 'up':    return key == LogicalKeyboardKey.arrowUp;
      case 'down':  return key == LogicalKeyboardKey.arrowDown;
      case 'left':  return key == LogicalKeyboardKey.arrowLeft;
      case 'right': return key == LogicalKeyboardKey.arrowRight;
      default:      return false;
    }
  }

  String? _swipeToDpad(double velocity, bool isVertical) {
    if (isVertical) {
      if (velocity >  400) return 'up';
      if (velocity < -400) return 'down';
    } else {
      if (velocity >  400) return 'left';
      if (velocity < -400) return 'right';
    }
    return null;
  }

  void _handleDpad(String dpad) {
    for (final action in [_kNext, _kPrev, _kSettings, _kChannelList]) {
      if (_gestureFor(action) == dpad) {
        _dispatchAction(action);
        return;
      }
    }
  }

  void _dispatchAction(String action) {
    switch (action) {
      case _kNext:        _nextChannel();        break;
      case _kPrev:        _prevChannel();        break;
      case _kSettings:    _openSettings();       break;
      case _kChannelList: _showChannelListUI();  break;
    }
  }

  // ── Channel list UI ────────────────────────────────────────────────────────

  String _persistedSearchTerm = '';

  Future<void> _showChannelListUI() async {
    if (_showChannels) {
      _hideChannelListUI();
      return;
    }

    if (_tapPausesVideo) {
      await ref.read(playerServiceProvider).togglePlayPause();
      setState(() => _videoPaused = true);
    }

    if (_isAndroid) {
      await ref.read(playerServiceProvider).setVideoVisible(false);
      // Hide subtitles while UI is overlaid
      ref.read(playerServiceProvider).setSubtitleVisible(false);
    }

    if (_persistedSearchTerm.isNotEmpty) {
      _activeSearchTerm = _persistedSearchTerm;
      final lower    = _persistedSearchTerm.toLowerCase();
      final filtered = _channels
          .where((c) => c.name.toLowerCase().contains(lower))
          .toList();
      _searchFilteredChannels = filtered.isNotEmpty ? filtered : null;
    }

    if (mounted) setState(() { _showChannels = true; _showIcons = true; });
    // Move keyboard/D-pad focus into the channel list
    WidgetsBinding.instance.addPostFrameCallback(
        (_) => _channelListFocus.requestFocus());
  }

  void _hideChannelListUI() {
    _persistedSearchTerm    = _activeSearchTerm;
    _searchFilteredChannels = null;
    _activeSearchTerm       = '';

    // Always resume if paused — closing the list must never leave video stopped.
    if (_videoPaused) {
      ref.read(playerServiceProvider).togglePlayPause();
      setState(() => _videoPaused = false);
    }

    if (_isAndroid) {
      ref.read(playerServiceProvider)
        ..setVideoVisible(true)
        ..setSubtitleVisible(true);
      Future.delayed(const Duration(milliseconds: 100), () {
        if (mounted) ref.read(playerServiceProvider).reapplyAspectRatio();
      });
    }

    setState(() { _showChannels = false; _showIcons = false; _bottomBarFocusIdx = -1; });
  }

  Future<void> _handleTap()          async => _showChannelListUI();
  void         _closeIcons()               => _hideChannelListUI();
  void         _closeChannelList()         => _hideChannelListUI();
  Future<void> _toggleChannelList()  async => _showChannelListUI();

  // ── Channel navigation ────────────────────────────────────────────────────

  Future<void> _playChannel(Channel channel, int index,
      {bool keepListOpen = false}) async {
    if (_isAndroid) {
      await ref.read(playerServiceProvider).setVideoVisible(true);
      Future.delayed(const Duration(milliseconds: 200), () {
        if (mounted) ref.read(playerServiceProvider).reapplyAspectRatio();
      });
    }
    if (_videoPaused) await ref.read(playerServiceProvider).togglePlayPause();
    if (_activeSearchTerm.isNotEmpty) {
      _persistedSearchTerm = _activeSearchTerm;
    }
    setState(() {
      if (!keepListOpen) {
        _showChannels      = false;
        _showIcons         = false;
        _bottomBarFocusIdx = -1;
      }
      _videoPaused = false;
    });

    // Pass subtitle preference and style to player
    final showSubs   = ref.read(subtitleSettingsProvider.notifier).showSubtitles;
    final subStyle   = ref.read(subtitleStyleProvider.notifier);
    final subBold    = ref.read(subtitleBoldProvider);
    await ref.read(playerServiceProvider).play(
      channel,
      showSubtitles:        showSubs,
      subtitleFontSize:     subStyle.fontSize,
      subtitleColorIndex:   subStyle.colorIndex,
      subtitleOutlineIndex: subStyle.outlineIndex,
      subtitleBold:         subBold,
      subtitleBottomOffset: subStyle.bottomOffset,
    );
    ref.read(currentChannelProvider.notifier).state      = channel;
    ref.read(currentChannelIndexProvider.notifier).state = index;
    final _plId = ref.read(activePlaylistIdProvider);
    await ref.read(playlistServiceProvider)
        .setLastChannelId(channel.id, playlistId: _plId);
    _showChannelNameBriefly();
    if (_isAndroid || Platform.isIOS) await WakelockPlus.enable();
  }

  Future<void> _nextChannel() async {
    final channels = _navigableChannels;
    if (channels.isEmpty) return;
    final currentId = ref.read(currentChannelProvider)?.id;
    int idx = channels.indexWhere((c) => c.id == currentId);
    if (idx < 0) idx = ref.read(currentChannelIndexProvider);
    final next    = (idx + 1) % channels.length;
    final ch      = channels[next];
    final fullIdx = _channels.indexOf(ch);
    await _playChannel(ch, fullIdx >= 0 ? fullIdx : next);
  }

  Future<void> _prevChannel() async {
    final channels = _navigableChannels;
    if (channels.isEmpty) return;
    final currentId = ref.read(currentChannelProvider)?.id;
    int idx = channels.indexWhere((c) => c.id == currentId);
    if (idx < 0) idx = ref.read(currentChannelIndexProvider);
    final prev    = (idx - 1 + channels.length) % channels.length;
    final ch      = channels[prev];
    final fullIdx = _channels.indexOf(ch);
    await _playChannel(ch, fullIdx >= 0 ? fullIdx : prev);
  }

  // ── Playlist navigation ───────────────────────────────────────────────────

  /// Gets a playlist by index from provider state, refreshing from network
  /// if channels are empty (happens when SharedPreferences didn't persist them).
  Future<IptvPlaylist> _getPlaylistWithChannels(IptvPlaylist p) async {
    if (p.channels.isNotEmpty) return p;
    debugPrint('[SWITCH] channels empty for "' + p.name + '", refreshing from network...');
    try {
      return await ref.read(playlistsProvider.notifier).refresh(p);
    } catch (e) {
      debugPrint('[SWITCH] refresh failed: ' + e.toString());
      return p;
    }
  }

  Future<void> _nextPlaylist() async {
    final playlists = ref.read(playlistsProvider);
    if (playlists.length < 2) return;
    final activeId = ref.read(activePlaylistIdProvider);
    final idx      = playlists.indexWhere((p) => p.id == activeId);
    var next       = playlists[(idx + 1) % playlists.length];
    next = await _getPlaylistWithChannels(next);
    debugPrint('[SWITCH] _nextPlaylist → "' + next.name + '" channels=' + next.channels.length.toString());
    await _switchPlaylist(next, announce: true);
    await _afterPlaylistSwitch(next);
  }

  Future<void> _prevPlaylist() async {
    final playlists = ref.read(playlistsProvider);
    if (playlists.length < 2) return;
    final activeId = ref.read(activePlaylistIdProvider);
    final idx      = playlists.indexWhere((p) => p.id == activeId);
    var prev       = playlists[(idx - 1 + playlists.length) % playlists.length];
    prev = await _getPlaylistWithChannels(prev);
    debugPrint('[SWITCH] _prevPlaylist → "' + prev.name + '" channels=' + prev.channels.length.toString());
    await _switchPlaylist(prev, announce: true);
    await _afterPlaylistSwitch(prev);
  }

  // ── Settings ──────────────────────────────────────────────────────────────

  Future<void> _openSettings() async {
    if (_tapPausesVideo && !_videoPaused) {
      await ref.read(playerServiceProvider).togglePlayPause();
      setState(() => _videoPaused = true);
    }
    if (_isAndroid) {
      await ref.read(playerServiceProvider).setVideoVisible(false);
      ref.read(playerServiceProvider).setSubtitleVisible(false);
    }
    setState(() { _showIcons = false; _showChannels = false; _settingsOpen = true; });
    if (!mounted) return;
    await Navigator.push(context,
        MaterialPageRoute(
            builder: (_) => const SettingsScreen(showBackButton: true)));
    if (!mounted) return;
    _settingsOpen = false;
    _ensureImmersive();
    if (_videoPaused) {
      await ref.read(playerServiceProvider).togglePlayPause();
      setState(() => _videoPaused = false);
    }
    if (_isAndroid) {
      await ref.read(playerServiceProvider).setVideoVisible(true);
      await ref.read(playerServiceProvider).reapplyAspectRatio();
      ref.read(playerServiceProvider).setSubtitleVisible(true);
      _applySubtitleStyle();  // pick up any style changes from settings
    }
  }

  // ── Key handling ──────────────────────────────────────────────────────────

  KeyEventResult _handleKey(FocusNode _, KeyEvent event) {
    if (event is! KeyDownEvent) return KeyEventResult.ignored;
    // If settings screen is pushed on top, ignore all keys — the settings
    // screen has its own Focus wrapper that handles them.
    if (_settingsOpen) return KeyEventResult.ignored;
    final key = event.logicalKey;
    final usb = event.physicalKey.usbHidUsage;

    if (usb == 0x000c0083) { _nextChannel(); return KeyEventResult.handled; }
    if (usb == 0x000c0084) { _prevChannel(); return KeyEventResult.handled; }
    if (key == LogicalKeyboardKey.mediaTrackNext) {
      _nextChannel(); return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.mediaTrackPrevious) {
      _prevChannel(); return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.mediaFastForward ||
        key == LogicalKeyboardKey.pageDown) {
      _nextPlaylist(); return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.mediaRewind ||
        key == LogicalKeyboardKey.pageUp) {
      _prevPlaylist(); return KeyEventResult.handled;
    }
    // Back: TV remote back button, keyboard Escape, or keyboard Backspace
    if (key == LogicalKeyboardKey.escape ||
        key == LogicalKeyboardKey.goBack ||
        key == LogicalKeyboardKey.backspace) {
      _handleBack(); return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.select || key == LogicalKeyboardKey.enter) {
      _handleTap(); return KeyEventResult.handled;
    }
    // Digit keys 0-9
    final digit = _keyToDigit(key);
    if (digit != null) {
      _handleDigit(digit);
      return KeyEventResult.handled;
    }
    // D-pad: when the channel list is visible, let it handle up/down/left/right
    // so the user can scroll through channels with the remote/keyboard.
    // The channel list's own FocusNode will receive the event via the Focus
    // widget wrapping it (see _channelListWidget). We just need to make sure
    // we don't also trigger a channel-switch from here.
    if (_showChannels) {
      for (final dpad in ['up', 'down', 'left', 'right']) {
        if (_dpadMatches(key, dpad)) {
          // Forward to the channel-list focus so its onKeyEvent fires
          // (it is already focused after _showChannelListUI, so Flutter
          //  will route key events there automatically — this path is only
          //  reached if somehow the outer Focus caught it first, which
          //  shouldn't happen, but we guard anyway).
          return KeyEventResult.ignored;
        }
      }
    }
    for (final dpad in ['up', 'down', 'left', 'right']) {
      if (_dpadMatches(key, dpad)) { _handleDpad(dpad); return KeyEventResult.handled; }
    }
    return KeyEventResult.ignored;
  }

  int? _keyToDigit(LogicalKeyboardKey key) {
    // Primary: named digit / numpad keys (physical keyboards, TV remotes)
    final named = {
      LogicalKeyboardKey.digit0: 0, LogicalKeyboardKey.digit1: 1,
      LogicalKeyboardKey.digit2: 2, LogicalKeyboardKey.digit3: 3,
      LogicalKeyboardKey.digit4: 4, LogicalKeyboardKey.digit5: 5,
      LogicalKeyboardKey.digit6: 6, LogicalKeyboardKey.digit7: 7,
      LogicalKeyboardKey.digit8: 8, LogicalKeyboardKey.digit9: 9,
      LogicalKeyboardKey.numpad0: 0, LogicalKeyboardKey.numpad1: 1,
      LogicalKeyboardKey.numpad2: 2, LogicalKeyboardKey.numpad3: 3,
      LogicalKeyboardKey.numpad4: 4, LogicalKeyboardKey.numpad5: 5,
      LogicalKeyboardKey.numpad6: 6, LogicalKeyboardKey.numpad7: 7,
      LogicalKeyboardKey.numpad8: 8, LogicalKeyboardKey.numpad9: 9,
    };
    if (named.containsKey(key)) return named[key];
    // Fallback: some Android keyboards report a single-char keyLabel '0'-'9'
    final label = key.keyLabel;
    if (label.length == 1) {
      final code = label.codeUnitAt(0) - 48; // '0' = 48
      if (code >= 0 && code <= 9) return code;
    }
    return null;
  }

  void _handleBack() {
    if (_showChannels) { _closeChannelList(); return; }
    if (_showIcons)    { _closeIcons();       return; }
    // On the player screen with no overlays, Back/Backspace exits the app.
    _exitApp();
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isTv = _isTv(size.width);
    return PopScope(
      onPopInvoked: (_) {
        ref.read(playerServiceProvider).stop();
        WakelockPlus.disable();
      },
      child: Focus(
        autofocus: true,
        onKeyEvent: _handleKey,
        child: Scaffold(
          backgroundColor: Colors.black,
          body: _buildLayout(size,
              tvMode: isTv, desktop: !isTv && _isDesktop),
        ),
      ),
    );
  }

  Widget _buildLayout(Size size,
      {required bool tvMode, required bool desktop}) {

    final dispNotifier   = ref.read(displaySettingsProvider.notifier);
    final listHeightFrac = dispNotifier.channelListHeight;
    final listHeight     = size.height * listHeightFrac;
    final listWidth      = tvMode ? 320.0 : 300.0;
    final bottomDead     = dispNotifier.bottomDeadZone;
    final topDead        = dispNotifier.topDeadZone;

    return Listener(
      onPointerDown:   (_) => _dragPointerCount++,
      onPointerUp:     (_) { if (_dragPointerCount > 0) _dragPointerCount--; },
      onPointerCancel: (_) { if (_dragPointerCount > 0) _dragPointerCount--; },
      child: GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _handleTap,
      onVerticalDragStart: (d) {
        _dragStartY    = d.globalPosition.dy;
        _twoFingerDrag = _dragPointerCount >= 2;
      },
      onVerticalDragEnd: (d) {
        final startY = _dragStartY;
        // Ignore swipes starting in bottom dead zone
        if (startY != null && startY > size.height * (1.0 - bottomDead)) return;
        // Ignore swipes starting in top dead zone
        if (startY != null && startY < size.height * topDead) return;
        if (_twoFingerDrag) {
          _twoFingerDrag = false;
          final v = d.primaryVelocity ?? 0;
          if (v > 400)  { _prevPlaylist(); return; }
          if (v < -400) { _nextPlaylist(); return; }
          return;
        }
        _twoFingerDrag = false;
        final g = _swipeToDpad(d.primaryVelocity ?? 0, true);
        if (g != null) _handleDpad(g);
      },
      onHorizontalDragStart: (d) {
        _dragStartX = d.globalPosition.dy;
      },
      onHorizontalDragEnd: (d) {
        final startY = _dragStartX;
        // Also apply dead zones to horizontal swipes starting in top/bottom
        if (startY != null && startY > size.height * (1.0 - bottomDead)) return;
        if (startY != null && startY < size.height * topDead) return;
        final g = _swipeToDpad(d.primaryVelocity ?? 0, false);
        if (g != null) _handleDpad(g);
      },
      child: Stack(
        children: [
          // ── Video ─────────────────────────────────────────────────────
          Positioned.fill(child: _buildVideoWidget()),

          // ── Dim overlay ───────────────────────────────────────────────
          if (_showChannels || _showIcons)
            Positioned.fill(
              child: Container(color: Colors.black.withOpacity(0.50)),
            ),

          // ── Channel list (TV / desktop: left panel) ───────────────────
          if (_showChannels && (tvMode || desktop))
            Positioned(
              top: 0, bottom: 0, left: 0,
              child: SizedBox(
                width: listWidth,
                child: _channelListWidget(tvMode: tvMode),
              ),
            ),
          if (_showChannels && !(tvMode || desktop))
            Positioned(
              top: 0, left: 0, right: 0,
              height: listHeight,
              child: _channelListWidget(tvMode: false),
            ),

          // ── Bottom icon bar ───────────────────────────────────────────
          if (_showIcons)
            Positioned(
              bottom: 0, left: 0, right: 0,
              child: SafeArea(
                top: false,
                child: _buildBottomBar(large: tvMode, focusedIdx: _bottomBarFocusIdx),
              ),
            ),

          // ── Channel name ──────────────────────────────────────────────
          if (_showChannelName && !_showChannels)
            Positioned(
              top: 0, left: 0, right: 0,
              child: SafeArea(
                bottom: false,
                child: _buildChannelNameBar(),
              ),
            ),

          // ── Number dial overlay ───────────────────────────────────────
          if (_dialBuffer.isNotEmpty)
            Positioned(
              bottom: 80, right: 20,
              child: _buildDialOverlay(),
            ),

          // ── Playlist change toast ─────────────────────────────────────
          if (_playlistToast != null)
            Positioned.fill(
              child: Center(child: _buildPlaylistToast(_playlistToast!)),
            ),

          // ── Desktop persistent bar ────────────────────────────────────
          if (desktop && !_showIcons)
            Positioned(
              bottom: 0, left: 0, right: 0,
              child: _buildDesktopBar(),
            ),
        ],
      ),
      ),
    );
  }

  // ── Dial overlay ──────────────────────────────────────────────────────────

  Widget _buildDialOverlay() {
    final bool isPlaylist = _dialBuffer.startsWith('0') && _dialBuffer.length >= 2;
    final label = isPlaylist
        ? 'Playlist ${_dialBuffer.substring(1)}'
        : 'Ch $_dialBuffer';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.80),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white24),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            _dialBuffer,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 40,
              fontWeight: FontWeight.bold,
              letterSpacing: 4,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(color: Colors.white54, fontSize: 13),
          ),
        ],
      ),
    );
  }

  // ── Playlist toast ────────────────────────────────────────────────────────

  Widget _buildPlaylistToast(String name) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 16),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.88),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white30),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 16),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.playlist_play, color: Colors.white70, size: 22),
          const SizedBox(width: 12),
          Flexible(
            child: Text(
              name,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  // ── Search state ──────────────────────────────────────────────────────────

  List<Channel>? _searchFilteredChannels;
  String _activeSearchTerm = '';

  void _onSearchChanged(String term, List<Channel> filtered) {
    _searchFilteredChannels = filtered.isEmpty ? null : filtered;
    _activeSearchTerm = term;
  }

  List<Channel> get _navigableChannels =>
      (_searchFilteredChannels != null && _activeSearchTerm.isNotEmpty)
          ? _searchFilteredChannels!
          : _channels;

  Widget _channelListWidget({required bool tvMode}) {
    final activePlaylist = ref.watch(activePlaylistProvider);
    final allPlaylists   = ref.watch(playlistsProvider);
    final activeIndex    = allPlaylists.indexWhere(
        (p) => p.id == activePlaylist?.id);

    return Material(
      elevation: 8,
      color: Colors.black87,
      child: ChannelList(
          channels:               _channels,
          currentChannelId:       ref.watch(currentChannelProvider)?.id,
          onTap:                  _playChannel,
          tvMode:                 tvMode,
          scrollToCurrentOnBuild: true,
          playlists:              allPlaylists,
          activePlaylistIndex:    activeIndex < 0 ? 0 : activeIndex,
          onPlaylistChanged:      (p) async {
            final freshP = await _getPlaylistWithChannels(p);
            await _switchPlaylist(freshP, announce: true);
            await _afterPlaylistSwitch(freshP);
          },
          onRefreshPlaylist:      _refreshPlaylist,
          onClose:                _hideChannelListUI,
          playlistName:           activePlaylist?.name,
          initialSearchTerm:      _persistedSearchTerm,
          onSearchChanged:        _onSearchChanged,
          onSaveSearch: (term, filtered) =>
              _saveSearchAsPlaylist(term, filtered, activePlaylist?.name ?? 'playlist'),
          onBack:                 _hideChannelListUI,
          externalFocusNode:      _channelListFocus,
          bottomBarActions:       _buildBottomBarActions(),
          onBottomBarFocusChanged: (idx) => setState(() => _bottomBarFocusIdx = idx),
        ),
    );
  }

  /// Returns ordered action callbacks matching the visible bottom bar buttons.
  /// Used by ChannelList for D-pad Right navigation.
  List<VoidCallback> _buildBottomBarActions() {
    final notifier = ref.read(toolbarLayoutProvider.notifier);
    final ordered  = notifier.orderedButtons;
    final buttons  = ordered.isEmpty
        ? ['nextChannel', 'nextPlaylist', 'settings', 'exit']
        : ordered;
    final actions = <VoidCallback>[];
    for (final key in buttons) {
      final cb = _buttonCallback(key);
      if (cb != null) actions.add(cb);
    }
    return actions;
  }

  VoidCallback? _buttonCallback(String key) {
    switch (key) {
      case 'nextChannel':  return _nextChannel;
      case 'prevChannel':  return _prevChannel;
      case 'nextPlaylist': return _nextPlaylist;
      case 'prevPlaylist': return _prevPlaylist;
      case 'settings':     return _openSettings;
      case 'exit':         return _exitApp;
      default:             return null;
    }
  }

  Future<void> _refreshPlaylist(IptvPlaylist playlist) async {
    try {
      await ref.read(playlistsProvider.notifier).refresh(playlist);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Update failed: $e'),
          duration: const Duration(seconds: 3),
        ));
      }
    }
  }

  Future<void> _switchPlaylist(IptvPlaylist playlist, {bool announce = false}) async {
    await ref.read(playlistServiceProvider).setActiveId(playlist.id);
    ref.read(activePlaylistIdProvider.notifier).state = playlist.id;
    _searchFilteredChannels = null;
    _activeSearchTerm       = '';
    _persistedSearchTerm    = '';
    if (mounted) setState(() {});
    if (announce) _showPlaylistToast(playlist.name);
  }

  Future<void> _saveSearchAsPlaylist(
      String term, List<Channel> channels, String playlistName) async {
    try {
      final svc = ref.read(playlistServiceProvider);
      final p = await svc.saveSearchAsPlaylist(
        playlistName: playlistName,
        searchTerm:   term,
        channels:     channels,
      );
      await ref.read(playlistsProvider.notifier).refresh(p);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Saved "${p.name}" — ${channels.length} channels'),
          duration: const Duration(seconds: 3),
        ));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Failed to save: $e'),
          backgroundColor: Colors.red.shade900,
        ));
      }
    }
  }

  // ── Video ─────────────────────────────────────────────────────────────────

  Widget _buildVideoWidget() {
    // On Android, ExoPlayer renders on a native SurfaceView behind Flutter.
    // The SubtitleView is placed above Flutter natively.
    // We use a transparent container here so neither the video nor the
    // subtitles are blocked by Flutter's own painting.
    if (_isAndroid) return const SizedBox.expand();
    final svc         = ref.read(playerServiceProvider);
    final showWebview = ref.watch(currentChannelProvider)?.isEncrypted ?? false;
    if (showWebview && svc.webViewController != null) {
      return WebViewWidget(controller: svc.webViewController!);
    }
    return Video(controller: svc.videoController, fit: BoxFit.contain);
  }

  // ── Channel name bar ──────────────────────────────────────────────────────

  Widget _buildChannelNameBar() {
    final channel      = ref.watch(currentChannelProvider);
    final idx          = ref.watch(currentChannelIndexProvider); // 0-based
    final allPlaylists = ref.watch(playlistsProvider);
    final activeId     = ref.watch(activePlaylistIdProvider);
    final plIdx        = allPlaylists.indexWhere((p) => p.id == activeId);
    final playlist     = plIdx >= 0 ? allPlaylists[plIdx] : null;
    final fontSize     = ref.watch(displaySettingsProvider.notifier)
        .channelNameFontSize;
    final smallSize    = (fontSize * 0.52).clamp(11.0, 20.0);
    final showPlOnOsd  = ref.watch(showPlaylistOnOsdProvider);

    final displayName = channel == null ? '' : '${idx + 1}  ${channel.name}';
    final playlistLine = (showPlOnOsd && playlist != null)
        ? '${plIdx + 1}/${allPlaylists.length}  ${playlist.name}'
        : '';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 48),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end:   Alignment.bottomCenter,
          colors: [
            Colors.black.withOpacity(0.90),
            Colors.transparent,
          ],
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          if (channel?.isEncrypted ?? false) ...[
            const Icon(Icons.key, color: Colors.orange, size: 22),
            const SizedBox(width: 10),
          ],
          Expanded(
            child: MediaQuery(
              data: MediaQuery.of(context).copyWith(
                  textScaler: TextScaler.noScaling),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    displayName,
                    style: TextStyle(
                      color:      Colors.white,
                      fontSize:   fontSize,
                      fontWeight: FontWeight.bold,
                      shadows: const [
                        Shadow(blurRadius: 12, color: Colors.black),
                        Shadow(blurRadius: 4,  color: Colors.black),
                      ],
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (playlistLine.isNotEmpty)
                    Text(
                      playlistLine,
                      style: TextStyle(
                        color:    Colors.white70,
                        fontSize: smallSize,
                        shadows: const [
                          Shadow(blurRadius: 8, color: Colors.black),
                        ],
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                ],
              ),
            ),
          ),
          if (_videoPaused)
            Padding(
              padding: const EdgeInsets.only(left: 14),
              child: Icon(Icons.pause_circle_filled,
                  color: Colors.white70, size: fontSize),
            ),
        ],
      ),
    );
  }

  // ── Bottom icon bar ───────────────────────────────────────────────────────

  void _exitApp() {
    ref.read(playerServiceProvider)
      ..setVideoVisible(true)
      ..stop();
    WakelockPlus.disable();
    SystemNavigator.pop();
  }

  /// Maps a toolbar button key to its icon, label, and action.
  _BarBtnData? _buttonData(String key, double iconSize) {
    switch (key) {
      case 'nextChannel':
        return _BarBtnData(
          icon: Icons.skip_next, label: 'Next Ch',
          iconSize: iconSize, onPressed: _nextChannel);
      case 'prevChannel':
        return _BarBtnData(
          icon: Icons.skip_previous, label: 'Prev Ch',
          iconSize: iconSize, onPressed: _prevChannel);
      case 'nextPlaylist':
        return _BarBtnData(
          icon: Icons.playlist_play, label: 'Next PL',
          iconSize: iconSize, onPressed: _nextPlaylist);
      case 'prevPlaylist':
        return _BarBtnData(
          icon: Icons.playlist_play, label: 'Prev PL',
          iconSize: iconSize, onPressed: _prevPlaylist);
      case 'settings':
        return _BarBtnData(
          icon: Icons.settings, label: 'Settings',
          iconSize: iconSize, onPressed: _openSettings);
      case 'exit':
        return _BarBtnData(
          icon: Icons.exit_to_app, label: 'Exit',
          iconSize: iconSize, onPressed: _exitApp);
      default:
        return null;
    }
  }

  Widget _buildBottomBar({bool large = false, int focusedIdx = -1}) {
    final iconSize = large ? 40.0 : 36.0;
    final layout   = ref.watch(toolbarLayoutProvider);
    final notifier = ref.read(toolbarLayoutProvider.notifier);
    final ordered  = notifier.orderedButtons;

    // Fallback: if layout is empty, show defaults
    final buttons = ordered.isEmpty
        ? ['nextChannel', 'nextPlaylist', 'settings', 'exit']
        : ordered;

    final btnDataList = buttons
        .map((k) => _buttonData(k, iconSize))
        .whereType<_BarBtnData>()
        .toList();

    return Container(
      color: Colors.black87,
      padding: EdgeInsets.symmetric(
          vertical: large ? 14 : 10, horizontal: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: btnDataList.asMap().entries.map((e) => _BarBtn(
              icon:      e.value.icon,
              label:     e.value.label,
              iconSize:  e.value.iconSize,
              onPressed: e.value.onPressed,
              focused:   e.key == focusedIdx,
            )).toList(),
      ),
    );
  }

  Widget _buildDesktopBar() {
    return Container(
      color: Colors.black54,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: Row(
        children: [
          IconButton(icon: const Icon(Icons.skip_previous, color: Colors.white),
              onPressed: _prevChannel),
          IconButton(icon: const Icon(Icons.skip_next, color: Colors.white),
              onPressed: _nextChannel),
          const Spacer(),
          IconButton(
            icon: Icon(_showChannels ? Icons.list : Icons.list_outlined,
                color: Colors.white),
            onPressed: _toggleChannelList,
          ),
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.white70),
            onPressed: _openSettings,
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _BarBtnData {
  final IconData icon;
  final String   label;
  final double   iconSize;
  final VoidCallback onPressed;
  const _BarBtnData({
    required this.icon,
    required this.label,
    required this.iconSize,
    required this.onPressed,
  });
}

class _BarBtn extends StatelessWidget {
  final IconData icon;
  final String   label;
  final double   iconSize;
  final VoidCallback onPressed;
  final bool focused;

  const _BarBtn({
    required this.icon,
    required this.label,
    required this.iconSize,
    required this.onPressed,
    this.focused = false,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 120),
      decoration: BoxDecoration(
        color: focused ? Colors.blue.withOpacity(0.30) : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: focused ? Colors.blue : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: focused ? Colors.blue : Colors.white, size: iconSize),
              const SizedBox(height: 5),
              Text(label,
                  style: TextStyle(
                      color: focused ? Colors.blue : Colors.white70,
                      fontSize: 12,
                      fontWeight: focused ? FontWeight.bold : FontWeight.normal)),
            ],
          ),
        ),
      ),
    );
  }
}
