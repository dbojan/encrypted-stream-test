// 26-03-28-1613
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/iptv_playlist.dart';
import '../providers/providers.dart';
import '../services/playlist_service.dart';

// Toolbar button metadata — keep in sync with ToolbarLayoutNotifier
const _kToolbarButtons = <String, ({String label, IconData icon})>{
  'nextChannel':  (label: 'Next channel',   icon: Icons.skip_next),
  'prevChannel':  (label: 'Prev channel',   icon: Icons.skip_previous),
  'nextPlaylist': (label: 'Next playlist',  icon: Icons.playlist_play),
  'prevPlaylist': (label: 'Prev playlist',  icon: Icons.playlist_play),
  'settings':     (label: 'Settings',       icon: Icons.settings),
  'exit':         (label: 'Exit',           icon: Icons.exit_to_app),
};

class SettingsScreen extends ConsumerStatefulWidget {
  final VoidCallback? onClose;
  final bool showBackButton;
  const SettingsScreen(
      {super.key, this.onClose, this.showBackButton = false});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  String? _selectedPlaylistId;
  bool    _loading = false;
  String? _error;
  String? _fetchingId;   // id of playlist currently being fetched in background

  @override
  void initState() {
    super.initState();
    final savedId = ref.read(playlistServiceProvider).getActiveId();
    final playlists = ref.read(playlistsProvider);
    // Only use the saved ID if it still exists in the playlist list.
    // A stale ID (e.g. from a deleted playlist) would crash the DropdownButton
    // because its value wouldn't match any item.
    if (savedId != null && playlists.any((p) => p.id == savedId)) {
      _selectedPlaylistId = savedId;
    } else if (savedId != null) {
      // FIX: stale active id in prefs — clear it so the DropdownButton gets
      // null (shows the hint) rather than an unmatched value that crashes.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        ref.read(activePlaylistIdProvider.notifier).state = null;
      });
    }
  }

  // ── Playlist actions ───────────────────────────────────────────────────────

  Future<void> _selectPlaylist(String id) async {
    final svc = ref.read(playlistServiceProvider);
    await svc.setActiveId(id);
    ref.read(activePlaylistIdProvider.notifier).state = id;
    setState(() { _selectedPlaylistId = id; _loading = true; _error = null; });
    try {
      final playlists = ref.read(playlistsProvider);
      final playlist  = playlists.firstWhere((p) => p.id == id);
      final updated   = await ref.read(playlistsProvider.notifier).refresh(playlist);
      if (updated.channels.isNotEmpty) {
        ref.read(currentChannelProvider.notifier).state      = updated.channels.first;
        ref.read(currentChannelIndexProvider.notifier).state = 0;
        await svc.setLastChannelId(updated.channels.first.id);
      }
    } catch (e) {
      setState(() => _error = 'Failed to load: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _updatePlaylist(IptvPlaylist playlist) async {
    setState(() { _loading = true; _error = null; });
    try {
      await ref.read(playlistsProvider.notifier).refresh(playlist);
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _selectPlaylistSilent(String id) async {
    final svc = ref.read(playlistServiceProvider);
    await svc.setActiveId(id);
    ref.read(activePlaylistIdProvider.notifier).state = id;
    setState(() => _selectedPlaylistId = id);
  }

  void _showAddDialog() {
    showDialog(
      context: context,
      builder: (_) => _PlaylistDialog(
        onSave: (name, url, cancelToken) async {
          // 1. Check for duplicate URL
          final existingPlaylists = ref.read(playlistsProvider);
          if (existingPlaylists.any((p) => p.url == url)) {
            if (mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('A playlist with this URL already exists')),
              );
            }
            return;
          }

          // 2. Resolve filename to full path (fast, local)
          final resolved = await PlaylistService.resolvePlaylistUrl(url);
          final finalUrl = resolved ?? url;
          if (cancelToken.isCancelled) return;

          // 3. Validate: local file must exist; remote URL must respond 200
          setState(() { _fetchingId = '__validating__'; _error = null; });
          try {
            await PlaylistService.validateUrl(finalUrl);
          } catch (e) {
            if (mounted && !cancelToken.isCancelled) {
              setState(() { _error = 'Cannot access playlist: $e'; _fetchingId = null; });
            }
            return;
          }
          if (cancelToken.isCancelled) {
            if (mounted) setState(() => _fetchingId = null);
            return;
          }

          // 4. Save immediately so playlist appears in list at once
          final p = await ref.read(playlistsProvider.notifier).add(name, finalUrl);
          await _selectPlaylistSilent(p.id);
          if (cancelToken.isCancelled) {
            await ref.read(playlistsProvider.notifier).delete(p.id);
            if (mounted) setState(() => _fetchingId = null);
            return;
          }

          // 5. Fetch channels in background
          setState(() { _fetchingId = p.id; _error = null; });
          try {
            await ref.read(playlistsProvider.notifier).refresh(p);
          } catch (e) {
            if (mounted && !cancelToken.isCancelled) {
              setState(() => _error = 'Failed to fetch: $e');
            }
          } finally {
            if (mounted) setState(() => _fetchingId = null);
          }
        },
      ),
    );
  }

  void _showEditDialog(IptvPlaylist playlist) {
    showDialog(
      context: context,
      builder: (_) => _PlaylistDialog(
        initialName: playlist.name,
        initialUrl:  playlist.url,
        onSave: (name, url, cancelToken) async {
          if (cancelToken.isCancelled) return;
          final resolved = await PlaylistService.resolvePlaylistUrl(url);
          final finalUrl = resolved ?? url;
          if (cancelToken.isCancelled) return;
          final updated = playlist.copyWith(name: name, url: finalUrl);
          await ref.read(playlistsProvider.notifier).update(updated);
        },
      ),
    );
  }

  void _deletePlaylist(String id) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.grey.shade900,
        title: const Text('Delete playlist?',
            style: TextStyle(color: Colors.white)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              await ref.read(playlistsProvider.notifier).delete(id);
              if (_selectedPlaylistId == id) {
                // FIX: also clear the provider state so no stale id lingers
                // in memory — without this the DropdownButton can crash on
                // the next rebuild if the provider still holds the old id.
                setState(() => _selectedPlaylistId = null);
                ref.read(activePlaylistIdProvider.notifier).state = null;
              }
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Future<void> _importFromFile() async {
    setState(() { _loading = true; _error = null; });
    try {
      final svc   = ref.read(playlistServiceProvider);
      final added = await svc.importFromFile();
      ref.invalidate(playlistsProvider);
      await Future.delayed(const Duration(milliseconds: 100));
      if (added == 0) {
        setState(() => _error = 'No new playlists found in esplayer.txt');
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Imported $added playlist(s) from esplayer.txt'),
          ));
        }
      }
    } catch (e) {
      setState(() => _error = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  // ── Build ─────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final playlists   = ref.watch(playlistsProvider);
    final interval    = ref.watch(updateIntervalProvider);
    final svc         = ref.read(playlistServiceProvider);
    final mapping     = ref.watch(controlMappingProvider);
    final tapSettings = ref.watch(tapSettingsProvider);
    final dispSettings = ref.watch(displaySettingsProvider);
    final dispNotifier = ref.read(displaySettingsProvider.notifier);
    // Watch these so the toolbar section rebuilds on change
    ref.watch(toolbarLayoutProvider);
    ref.watch(subtitleStyleProvider);
    ref.watch(subtitleBoldProvider);
    ref.watch(playlistToastProvider);
    ref.watch(playlistSwitchStartProvider);
    ref.watch(showPlaylistOnOsdProvider);
    final subStyleNotifier = ref.read(subtitleStyleProvider.notifier);

    // FIX: guard against a stale _selectedPlaylistId that no longer exists in
    // the current playlists list (e.g. after a delete races with a rebuild).
    // Resetting it here — before the DropdownButton is built — prevents the
    // "value not found in items" assertion crash.
    if (_selectedPlaylistId != null &&
        !playlists.any((p) => p.id == _selectedPlaylistId)) {
      _selectedPlaylistId = null;
    }

    IptvPlaylist? selectedPlaylist;
    if (_selectedPlaylistId != null) {
      try {
        selectedPlaylist =
            playlists.firstWhere((p) => p.id == _selectedPlaylistId);
      } catch (_) {}
    }

    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ── App bar ──────────────────────────────────────────────────────
        AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: const Text('Settings',
              style: TextStyle(color: Colors.white, fontSize: 18)),
          leading: widget.showBackButton || widget.onClose != null
              ? IconButton(
                  autofocus: true,
                  icon: Icon(
                      widget.showBackButton ? Icons.arrow_back : Icons.close,
                      color: Colors.white),
                  onPressed:
                      widget.onClose ?? () => Navigator.of(context).pop(),
                )
              : null,
        ),
        const Divider(color: Colors.white12),

        Expanded(
          child: FocusTraversalGroup(
            policy: WidgetOrderTraversalPolicy(),
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [

              // ── PLAYLISTS ─────────────────────────────────────────────
              _sectionLabel('PLAYLISTS'),
              const SizedBox(height: 8),

              if (playlists.isEmpty)
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 8),
                  child: Text('No playlists added yet.',
                      style: TextStyle(color: Colors.white54)),
                )
              else
                _dropdown(
                  child: DropdownButton<String>(
                    value:         _selectedPlaylistId,
                    isExpanded:    true,
                    dropdownColor: Colors.grey.shade800,
                    underline:     const SizedBox(),
                    hint: const Text('Select active playlist',
                        style: TextStyle(color: Colors.white54)),
                    items: playlists
                        .fold<Map<String, IptvPlaylist>>({}, (map, p) {
                          map.putIfAbsent(p.id, () => p);
                          return map;
                        })
                        .values
                        .map((p) => DropdownMenuItem<String>(
                      value: p.id,
                      child: Text('${p.name}  (${p.channels.length} ch)',
                          style: const TextStyle(color: Colors.white),
                          overflow: TextOverflow.ellipsis),
                    )).toList(),
                    onChanged: (id) { if (id != null) _selectPlaylist(id); },
                  ),
                ),

              const SizedBox(height: 8),

              // Selected playlist info card
              if (selectedPlaylist != null) ...[
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.black26,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(selectedPlaylist.name,
                          style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text(selectedPlaylist.url,
                          style: const TextStyle(
                              color: Colors.white54, fontSize: 12),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 4),
                      Text(
                        '${selectedPlaylist.channels.length} channels'
                        '${selectedPlaylist.lastUpdated != null ? ' · ${_timeAgo(selectedPlaylist.lastUpdated!)}' : ''}',
                        style: const TextStyle(
                            color: Colors.white38, fontSize: 12),
                      ),
                      const SizedBox(height: 8),
                      FocusTraversalGroup(
                        policy: OrderedTraversalPolicy(),
                        child: Row(children: [
                          FocusTraversalOrder(order: const NumericFocusOrder(1),
                            child: _actionBtn(icon: Icons.refresh, label: 'Update',
                                onPressed: _loading
                                    ? null
                                    : () => _updatePlaylist(selectedPlaylist!))),
                          FocusTraversalOrder(order: const NumericFocusOrder(2),
                            child: _actionBtn(icon: Icons.edit, label: 'Edit',
                                onPressed: () => _showEditDialog(selectedPlaylist!))),
                          FocusTraversalOrder(order: const NumericFocusOrder(3),
                            child: _actionBtn(icon: Icons.delete, label: 'Delete',
                                color: Colors.red.shade300,
                                onPressed: () => _deletePlaylist(selectedPlaylist!.id))),
                        ]),
                      ),
                      if (_loading || _fetchingId == selectedPlaylist?.id
                          || _fetchingId == '__validating__')
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const LinearProgressIndicator(),
                              const SizedBox(height: 4),
                              Text(
                                _fetchingId == '__validating__'
                                    ? 'Checking playlist…'
                                    : _fetchingId == selectedPlaylist?.id
                                        ? 'Fetching channels…'
                                        : 'Updating…',
                                style: const TextStyle(
                                    color: Colors.white38, fontSize: 11),
                              ),
                            ],
                          ),
                        ),
                      if (_error != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Text(_error!,
                              style: TextStyle(
                                  color: Colors.red.shade300, fontSize: 12)),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
              ],

              FocusTraversalGroup(
                policy: OrderedTraversalPolicy(),
                child: Row(children: [
                  Expanded(
                    child: FocusTraversalOrder(order: const NumericFocusOrder(10),
                      child: OutlinedButton.icon(
                        icon:  const Icon(Icons.add),
                        label: const Text('Add playlist'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(color: Colors.white24),
                        ),
                        onPressed: _showAddDialog,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  FocusTraversalOrder(order: const NumericFocusOrder(11),
                    child: OutlinedButton.icon(
                      icon:  const Icon(Icons.file_open, size: 16),
                      label: const Text('Import file'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white70,
                        side: const BorderSide(color: Colors.white12),
                      ),
                      onPressed: _loading ? null : _importFromFile,
                    ),
                  ),
                ]),
              ),

              Padding(
                padding: const EdgeInsets.only(top: 6, bottom: 2),
                child: Text(
                  'Auto-import from: ${PlaylistService.getEsPlayerPath()}',
                  style: const TextStyle(color: Colors.white24, fontSize: 10),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(
                  'Tip: enter just a filename (e.g. star.m3u) to load from Documents/',
                  style: const TextStyle(color: Colors.white24, fontSize: 10),
                ),
              ),

              const Divider(color: Colors.white12, height: 32),

              // ── AUTO-UPDATE ───────────────────────────────────────────
              _sectionLabel('AUTO-UPDATE'),
              const SizedBox(height: 8),
              _LabelRow(
                label: 'Update interval',
                trailing: const SizedBox.shrink(),
              ),
              const SizedBox(height: 4),
              _ChipSelectRow(
                options: const ['30 min', '1 hour', '2 hours', '6 hours', '24 hours'],
                selectedIndex: const [30, 60, 120, 360, 1440].indexOf(interval).clamp(0, 4),
                onChanged: (i) async {
                  const vals = [30, 60, 120, 360, 1440];
                  ref.read(updateIntervalProvider.notifier).state = vals[i];
                  await svc.setInterval(vals[i]);
                },
              ),
              const SizedBox(height: 8),
              _SwitchRow(
                label:    'Auto-load Documents/*.m3u',
                subtitle: 'Automatically add new .m3u/.m3u8 files found in Documents/ on startup',
                value:    ref.watch(autoLoadM3uProvider),
                onChanged: (v) async {
                  ref.read(autoLoadM3uProvider.notifier).state = v;
                  await svc.setAutoLoadM3u(v);
                },
              ),

              const Divider(color: Colors.white12, height: 32),

              // ── SUBTITLES ─────────────────────────────────────────────
              _sectionLabel('SUBTITLES'),
              const SizedBox(height: 4),
              _SwitchRow(
                label:    'Show subtitles',
                subtitle: 'Display subtitles / closed captions when present in stream',
                value:    (ref.watch(subtitleSettingsProvider)['showSubtitles'] ?? true),
                onChanged: (v) {
                  ref.read(subtitleSettingsProvider.notifier).set('showSubtitles', v);
                  ref.read(playerServiceProvider).setSubtitleVisible(v);
                },
              ),
              const SizedBox(height: 10),

              // Color
              _LabelRow(label: 'Color', trailing: const SizedBox.shrink()),
              const SizedBox(height: 6),
              _ChipSelectRow(
                options: const ['White', 'Yellow', 'Cyan', 'Green'],
                colors:  const [Colors.white, Colors.yellow, Colors.cyan, Colors.green],
                selectedIndex: subStyleNotifier.colorIndex,
                onChanged: (i) {
                  ref.read(subtitleStyleProvider.notifier).set('colorIndex', i.toDouble());
                  ref.read(playerServiceProvider).setSubtitleStyle(colorIndex: i);
                },
              ),
              const SizedBox(height: 12),

              // Outline
              _LabelRow(label: 'Outline', trailing: const SizedBox.shrink()),
              const SizedBox(height: 6),
              _ChipSelectRow(
                options: const ['None', 'Outline', 'Shadow'],
                selectedIndex: subStyleNotifier.outlineIndex,
                onChanged: (i) {
                  ref.read(subtitleStyleProvider.notifier).set('outlineIndex', i.toDouble());
                  ref.read(playerServiceProvider).setSubtitleStyle(outlineIndex: i);
                },
              ),
              const SizedBox(height: 4),

              // Font size
              _LabelRow(
                label: 'Font size',
                trailing: Text(
                  '${subStyleNotifier.fontSize.round()} sp',
                  style: const TextStyle(color: Colors.white54, fontSize: 13),
                ),
              ),
              _DpadSlider(
                value:    subStyleNotifier.fontSize.clamp(10.0, 60.0),
                min: 10, max: 60, divisions: 25,
                label:    '${subStyleNotifier.fontSize.round()} sp',
                onChanged: (v) {
                  ref.read(subtitleStyleProvider.notifier).set('fontSize', v);
                  ref.read(playerServiceProvider).setSubtitleStyle(fontSize: v);
                },
              ),

              // Bold
              _SwitchRow(
                label:    'Bold',
                subtitle: 'Use bold font weight for subtitles',
                value:    ref.watch(subtitleBoldProvider),
                onChanged: (v) {
                  ref.read(subtitleBoldProvider.notifier).set(v);
                  ref.read(playerServiceProvider).setSubtitleStyle(bold: v);
                },
              ),
              const SizedBox(height: 4),

              // Bottom offset
              _LabelRow(
                label: 'Distance from bottom',
                trailing: Text(
                  '${(subStyleNotifier.bottomOffset * 100).round()}%',
                  style: const TextStyle(color: Colors.white54, fontSize: 13),
                ),
              ),
              _DpadSlider(
                value:    subStyleNotifier.bottomOffset,
                min: 0.0, max: 0.40, divisions: 16,
                label:    '${(subStyleNotifier.bottomOffset * 100).round()}%',
                onChanged: (v) {
                  ref.read(subtitleStyleProvider.notifier).set('bottomOffset', v);
                  ref.read(playerServiceProvider).setSubtitleStyle(bottomOffset: v);
                },
              ),

              const Divider(color: Colors.white12, height: 32),

              // ── PLAYLIST TOAST ────────────────────────────────────────
              _sectionLabel('PLAYLIST CHANGE NOTIFICATION'),
              const SizedBox(height: 4),
              _SwitchRow(
                label:    'Show playlist name on switch',
                subtitle: 'Show a notification in the centre of the screen when switching playlists',
                value:    (ref.watch(playlistToastProvider)['showToast'] ?? true),
                onChanged: (v) =>
                    ref.read(playlistToastProvider.notifier).set('showToast', v),
              ),

              const Divider(color: Colors.white12, height: 32),
              _sectionLabel('ON PLAYLIST SWITCH'),
              const SizedBox(height: 4),
              const Text(
                'When switching playlists (via UI, remote buttons, or number dial), '
                'which channel should start playing?',
                style: TextStyle(color: Colors.white38, fontSize: 11),
              ),
              const SizedBox(height: 8),
              _ChipSelectRow(
                options: const ['First channel', 'Last played'],
                selectedIndex: ref.watch(playlistSwitchStartProvider) == 'last' ? 1 : 0,
                onChanged: (i) => ref.read(playlistSwitchStartProvider.notifier)
                    .set(i == 1 ? 'last' : 'first'),
              ),
              const SizedBox(height: 8),
              const SizedBox(height: 4),
              _SwitchRow(
                label:    'Show playlist name on OSD',
                subtitle: 'Display playlist name below channel name during playback',
                value:    ref.watch(showPlaylistOnOsdProvider),
                onChanged: (v) => ref
                    .read(showPlaylistOnOsdProvider.notifier).set(v),
              ),

              const Divider(color: Colors.white12, height: 32),
              _sectionLabel('DISPLAY'),
              const SizedBox(height: 10),

              // Channel name font size
              _LabelRow(
                label: 'Channel name size',
                trailing: Text(
                  '${dispNotifier.channelNameFontSize.round()} pt',
                  style: const TextStyle(color: Colors.white54, fontSize: 13),
                ),
              ),
              _DpadSlider(
                value:    dispNotifier.channelNameFontSize,
                min:      16, max: 56, divisions: 10,
                label:    '${dispNotifier.channelNameFontSize.round()} pt',
                onChanged: (v) => ref
                    .read(displaySettingsProvider.notifier)
                    .set('channelNameFontSize', v),
              ),

              // Channel name display duration
              _LabelRow(
                label: 'Channel name duration',
                trailing: Text(
                  '${dispNotifier.channelNameDuration} s',
                  style: const TextStyle(color: Colors.white54, fontSize: 13),
                ),
              ),
              _DpadSlider(
                value:    dispNotifier.channelNameDuration.toDouble(),
                min:      1, max: 15, divisions: 14,
                label:    '${dispNotifier.channelNameDuration} s',
                onChanged: (v) => ref
                    .read(displaySettingsProvider.notifier)
                    .set('channelNameDuration', v),
              ),

              // Channel list height
              _LabelRow(
                label: 'Channel list height',
                trailing: Text(
                  '${(dispNotifier.channelListHeight * 100).round()}%',
                  style: const TextStyle(color: Colors.white54, fontSize: 13),
                ),
              ),
              _DpadSlider(
                value:    dispNotifier.channelListHeight,
                min:      0.40, max: 1.0, divisions: 12,
                label:    '${(dispNotifier.channelListHeight * 100).round()}%',
                onChanged: (v) => ref
                    .read(displaySettingsProvider.notifier)
                    .set('channelListHeight', v),
              ),

              // App font scale
              _LabelRow(
                label: 'App font size',
                trailing: Text(
                  '${(dispNotifier.appFontScale * 100).round()}%',
                  style: const TextStyle(color: Colors.white54, fontSize: 13),
                ),
              ),
              _DpadSlider(
                value:    dispNotifier.appFontScale,
                min:      1.0, max: 2.0, divisions: 10,
                label:    '${(dispNotifier.appFontScale * 100).round()}%',
                onChanged: (v) => ref
                    .read(displaySettingsProvider.notifier)
                    .set('appFontScale', v),
              ),

              // Swipe dead zone (top & bottom combined)
              _LabelRow(
                label: 'Ignore top & bottom swipe area',
                trailing: Text(
                  dispNotifier.swipeDeadZone == 0
                      ? 'Off'
                      : '${(dispNotifier.swipeDeadZone * 100).round()}%',
                  style: const TextStyle(color: Colors.white54, fontSize: 13),
                ),
              ),
              _DpadSlider(
                value:    dispNotifier.swipeDeadZone,
                min:      0.0, max: 0.25, divisions: 5,
                label:    dispNotifier.swipeDeadZone == 0
                    ? 'Off'
                    : '${(dispNotifier.swipeDeadZone * 100).round()}%',
                onChanged: (v) => ref
                    .read(displaySettingsProvider.notifier)
                    .set('swipeDeadZone', v),
              ),

              const Divider(color: Colors.white12, height: 32),

              // ── ON TAP ────────────────────────────────────────────────
              _sectionLabel('ON TAP'),
              const SizedBox(height: 4),
              _SwitchRow(
                label:    'Pause on tap',
                subtitle: 'Pause playback when channel list or controls appear',
                value:    tapSettings['pauseVideo'] ?? true,
                onChanged: (v) {
                  ref.read(tapSettingsProvider.notifier).set('pauseVideo', v);
                  // Pause if playing — never resume from here
                  final player = ref.read(playerServiceProvider);
                  player.pauseIfPlaying();
                },
              ),

              const Divider(color: Colors.white12, height: 32),

              // ── TOOLBAR LAYOUT ────────────────────────────────────────
              _sectionLabel('ICONS AT THE BOTTOM'),
              const SizedBox(height: 4),
              const Text(
                'Set the position (1–4) of each icon shown at the bottom during playback, '
                'or disable it. Conflicts are highlighted in red.',
                style: TextStyle(color: Colors.white38, fontSize: 11),
              ),
              const SizedBox(height: 10),
              ..._kToolbarButtons.entries.map((entry) {
                final key     = entry.key;
                final meta    = entry.value;
                final layout  = ref.watch(toolbarLayoutProvider);
                final notifier = ref.read(toolbarLayoutProvider.notifier);
                final pos     = layout[key] ?? 0;
                final conflict = notifier.hasConflict(key);
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: _ToolbarButtonRow(
                    icon:     meta.icon,
                    label:    meta.label,
                    position: pos,
                    conflict: conflict,
                    onChanged: (v) => notifier.set(key, v),
                  ),
                );
              }),
              const SizedBox(height: 8),

              const Divider(color: Colors.white12, height: 32),

              // ── CONTROLS ─────────────────────────────────────────────
              _sectionLabel('CONTROLS'),
              const SizedBox(height: 12),

              _ControlRow(label: 'Next channel',  action: 'nextChannel',  mapping: mapping),
              const SizedBox(height: 10),
              _ControlRow(label: 'Prev channel',  action: 'prevChannel',  mapping: mapping),
              const SizedBox(height: 10),
              _ControlRow(label: 'Open settings', action: 'settings',     mapping: mapping),
              const SizedBox(height: 10),
              _ControlRow(label: 'Channel list',  action: 'channelList',  mapping: mapping),
              const SizedBox(height: 24),
              ],
            ),   // ListView
          ),   // FocusTraversalGroup
        ),
      ],
    );

    // Swipe right → back;  swipe down → update current playlist
    // Override the app-wide focus highlight so keyboard/D-pad focus is clearly
    // visible in the settings list (white outline around the focused widget).
    return Theme(
      data: Theme.of(context).copyWith(
        focusColor: Colors.white24,
      ),
      child: Focus(
        // Catch Backspace / Escape / goBack at the screen level so the
        // remote Back button and keyboard Backspace both navigate back.
        onKeyEvent: (_, event) {
          if (event is! KeyDownEvent) return KeyEventResult.ignored;
          final key = event.logicalKey;
          if (key == LogicalKeyboardKey.backspace ||
              key == LogicalKeyboardKey.escape ||
              key == LogicalKeyboardKey.goBack) {
            if (widget.onClose != null) {
              widget.onClose!();
            } else {
              Navigator.of(context).maybePop();
            }
            return KeyEventResult.handled;
          }
          return KeyEventResult.ignored;
        },
        child: GestureDetector(
          onHorizontalDragEnd: (d) {
            if ((d.primaryVelocity ?? 0) > 400) Navigator.of(context).maybePop();
          },
          onVerticalDragEnd: (d) {
            if ((d.primaryVelocity ?? 0) > 400 && _selectedPlaylistId != null) {
              try {
                final p = ref.read(playlistsProvider)
                    .firstWhere((p) => p.id == _selectedPlaylistId);
                _updatePlaylist(p);
              } catch (_) {}
            }
          },
          child: Scaffold(
            backgroundColor: Colors.grey.shade900,
            body: content,
          ),
        ),  // GestureDetector
      ),    // Focus
    );      // Theme
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  Widget _dropdown({required Widget child}) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
    decoration: BoxDecoration(
      color: Colors.black38,
      borderRadius: BorderRadius.circular(8),
      border: Border.all(color: Colors.white12),
    ),
    child: child,
  );

  Widget _sectionLabel(String text) => Padding(
    padding: const EdgeInsets.only(top: 8, bottom: 4),
    child: Text(text,
        style: const TextStyle(
            color: Colors.white38, fontSize: 11, letterSpacing: 1.2)),
  );

  Widget _actionBtn({
    required IconData icon,
    required String label,
    required VoidCallback? onPressed,
    Color? color,
  }) => TextButton.icon(
    icon:  Icon(icon, size: 16, color: color ?? Colors.white70),
    label: Text(label,
        style: TextStyle(color: color ?? Colors.white70, fontSize: 12)),
    style: TextButton.styleFrom(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      minimumSize: Size.zero,
      tapTargetSize: MaterialTapTargetSize.shrinkWrap,
    ),
    onPressed: onPressed,
  );

  static String _timeAgo(DateTime dt) {
    final d = DateTime.now().difference(dt);
    if (d.inMinutes < 60) return '${d.inMinutes}m ago';
    if (d.inHours < 24)   return '${d.inHours}h ago';
    return '${d.inDays}d ago';
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Small helpers
// ─────────────────────────────────────────────────────────────────────────────

class _LabelRow extends StatelessWidget {
  final String label;
  final Widget trailing;
  const _LabelRow({required this.label, required this.trailing});

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Expanded(child: Text(label,
          style: const TextStyle(color: Colors.white, fontSize: 13))),
      trailing,
    ],
  );
}

class _SwitchRow extends StatefulWidget {
  final String label;
  final String subtitle;
  final bool   value;
  final ValueChanged<bool> onChanged;

  const _SwitchRow({
    required this.label,
    required this.subtitle,
    required this.value,
    required this.onChanged,
  });

  @override
  State<_SwitchRow> createState() => _SwitchRowState();
}

class _SwitchRowState extends State<_SwitchRow> {
  final FocusNode _focus = FocusNode();

  @override
  void dispose() { _focus.dispose(); super.dispose(); }

  KeyEventResult _onKey(FocusNode _, KeyEvent event) {
    if (event is! KeyDownEvent && event is! KeyRepeatEvent) {
      return KeyEventResult.ignored;
    }
    final key = event.logicalKey;
    // Left → turn off, Right → turn on, Enter/Select → toggle
    if (key == LogicalKeyboardKey.arrowLeft) {
      if (widget.value) widget.onChanged(false);
      return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.arrowRight) {
      if (!widget.value) widget.onChanged(true);
      return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.enter ||
        key == LogicalKeyboardKey.select ||
        key == LogicalKeyboardKey.numpadEnter) {
      widget.onChanged(!widget.value);
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) => Focus(
    focusNode:       _focus,
    onKeyEvent:      _onKey,
    skipTraversal:   false,
    canRequestFocus: true,
    child: ListenableBuilder(listenable: _focus, builder: (ctx, _) {
      final focused = _focus.hasFocus;
      return GestureDetector(
        onTap: () {
          _focus.requestFocus();
          widget.onChanged(!widget.value);
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          margin:  const EdgeInsets.symmetric(vertical: 4),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          decoration: BoxDecoration(
            color: focused ? Colors.blue.withOpacity(0.15) : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: focused ? Colors.blue : Colors.transparent,
              width: 1.5,
            ),
          ),
          child: Row(children: [
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.label,
                    style: TextStyle(
                        color: focused ? Colors.white : Colors.white,
                        fontSize: 13,
                        fontWeight: focused ? FontWeight.w600 : FontWeight.normal)),
                Text(widget.subtitle,
                    style: const TextStyle(color: Colors.white38, fontSize: 11)),
              ],
            )),
            // Show ◀ OFF / ON ▶ hint when focused so user knows Left/Right works
            if (focused) ...[
              Text('◀', style: TextStyle(
                  color: widget.value ? Colors.white38 : Colors.blue,
                  fontSize: 12)),
              const SizedBox(width: 4),
            ],
            Switch(value: widget.value, onChanged: widget.onChanged,
                activeColor: Colors.blue),
            if (focused) ...[
              const SizedBox(width: 4),
              Text('▶', style: TextStyle(
                  color: widget.value ? Colors.blue : Colors.white38,
                  fontSize: 12)),
            ],
          ]),
        ),
      );
    }),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Control mapping row
// ─────────────────────────────────────────────────────────────────────────────

class _ControlRow extends ConsumerWidget {
  final String label;
  final String action;
  final Map<String, String> mapping;

  const _ControlRow({
    required this.label,
    required this.action,
    required this.mapping,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final current     = mapping[action] ?? 'down';
    final notifier    = ref.read(controlMappingProvider.notifier);
    final hasConflict = notifier.conflictFor(action, current) != null;

    return Row(children: [
      SizedBox(
        width: 110,
        child: Text(label,
            style: TextStyle(
              color:    hasConflict ? Colors.red.shade300 : Colors.white,
              fontSize: 13,
            )),
      ),
      Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
          decoration: BoxDecoration(
            color:  hasConflict
                ? Colors.red.shade900.withOpacity(0.4)
                : Colors.black38,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
                color: hasConflict ? Colors.red.shade700 : Colors.white12),
          ),
          child: DropdownButton<String>(
            value:         current,
            isExpanded:    true,
            dropdownColor: Colors.grey.shade800,
            underline:     const SizedBox(),
            style: TextStyle(
                color:    hasConflict ? Colors.red.shade300 : Colors.white,
                fontSize: 13),
            items: const [
              DropdownMenuItem(value: 'up',    child: Text('Up')),
              DropdownMenuItem(value: 'down',  child: Text('Down')),
              DropdownMenuItem(value: 'left',  child: Text('Left')),
              DropdownMenuItem(value: 'right', child: Text('Right')),
              DropdownMenuItem(value: 'tap',   child: Text('Tap / OK')),
            ],
            onChanged: (v) async {
              if (v == null) return;
              await notifier.set(action, v);
            },
          ),
        ),
      ),
    ]);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Toolbar button position row
// ─────────────────────────────────────────────────────────────────────────────

class _ToolbarButtonRow extends StatelessWidget {
  final IconData icon;
  final String   label;
  final int      position;   // 0 = disabled, 1–4 = slot
  final bool     conflict;
  final ValueChanged<int> onChanged;

  const _ToolbarButtonRow({
    required this.icon,
    required this.label,
    required this.position,
    required this.conflict,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Icon(icon, color: conflict ? Colors.red.shade300 : Colors.white54, size: 18),
      const SizedBox(width: 8),
      SizedBox(
        width: 110,
        child: Text(label,
            style: TextStyle(
              color:    conflict ? Colors.red.shade300 : Colors.white,
              fontSize: 13,
            )),
      ),
      Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
          decoration: BoxDecoration(
            color:  conflict
                ? Colors.red.shade900.withOpacity(0.4)
                : Colors.black38,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(
                color: conflict ? Colors.red.shade700 : Colors.white12),
          ),
          child: DropdownButton<int>(
            value:         position,
            isExpanded:    true,
            dropdownColor: Colors.grey.shade800,
            underline:     const SizedBox(),
            style: TextStyle(
                color:    conflict ? Colors.red.shade300 : Colors.white,
                fontSize: 13),
            items: const [
              DropdownMenuItem(value: 0, child: Text('Disabled')),
              DropdownMenuItem(value: 1, child: Text('Position 1')),
              DropdownMenuItem(value: 2, child: Text('Position 2')),
              DropdownMenuItem(value: 3, child: Text('Position 3')),
              DropdownMenuItem(value: 4, child: Text('Position 4')),
            ],
            onChanged: (v) { if (v != null) onChanged(v); },
          ),
        ),
      ),
    ]);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Playlist add / edit dialog
// ─────────────────────────────────────────────────────────────────────────────

class _PlaylistDialog extends StatefulWidget {
  final String? initialName;
  final String? initialUrl;
  /// Called with (name, url, cancelToken). The caller checks cancelToken
  /// throughout the async work so Cancel stops the operation.
  final Future<void> Function(String name, String url, _CancelToken cancel) onSave;

  const _PlaylistDialog({
    this.initialName,
    this.initialUrl,
    required this.onSave,
  });

  @override
  State<_PlaylistDialog> createState() => _PlaylistDialogState();
}

class _PlaylistDialogState extends State<_PlaylistDialog> {
  late final TextEditingController _nameCtrl;
  late final TextEditingController _urlCtrl;
  bool _saving = false;
  final _CancelToken _cancelToken = _CancelToken();

  @override
  void initState() {
    super.initState();
    _nameCtrl = TextEditingController(text: widget.initialName ?? '');
    _urlCtrl  = TextEditingController(text: widget.initialUrl  ?? '');
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _urlCtrl.dispose();
    super.dispose();
  }

  /// Derives a friendly playlist name from a URL or bare filename.
  ///
  /// Rules:
  ///  - Bare filename  "star.m3u"              → "star"
  ///  - Full URL       "http://mysite.com/1.m3u" → "mysite-1"
  ///  - URL no path    "http://mysite.com/"       → "mysite"
  static String _deriveName(String url) {
    final trimmed = url.trim();

    // Bare filename (no scheme)
    if (!trimmed.contains('://')) {
      return trimmed
          .split(RegExp(r'[/\\]')).last
          .replaceAll(RegExp(r'\.(m3u8?|txt)$', caseSensitive: false), '')
          .replaceAll('_', ' ')
          .trim()
          .ifEmpty('Playlist');
    }

    // Full URL — combine cleaned host + cleaned last path segment
    final uri = Uri.tryParse(trimmed);
    if (uri == null) return 'Playlist';

    // Clean host: strip www. prefix
    final host = (uri.host.startsWith('www.')
            ? uri.host.substring(4)
            : uri.host)
        .split('.') // take only the domain label, drop TLD
        .first;

    // Last meaningful path segment, stripped of extension
    final segments = uri.pathSegments.where((s) => s.isNotEmpty).toList();
    final filePart = segments.isNotEmpty
        ? segments.last
            .replaceAll(RegExp(r'\.(m3u8?|txt)$', caseSensitive: false), '')
            .replaceAll('_', ' ')
            .trim()
        : '';

    if (filePart.isEmpty || filePart == host) return host.ifEmpty('Playlist');
    return '$host-$filePart'.ifEmpty('Playlist');
  }

  Future<void> _save() async {
    final url = _urlCtrl.text.trim();
    if (url.isEmpty) return;

    String name = _nameCtrl.text.trim();
    if (name.isEmpty) name = _deriveName(url);

    setState(() => _saving = true);
    // Don't await — let it run; cancel button sets the token and closes dialog
    widget.onSave(name, url, _cancelToken).whenComplete(() {
      if (mounted) setState(() => _saving = false);
    });
    // Close the dialog immediately so the user isn't stuck staring at a spinner
    if (mounted) Navigator.pop(context);
  }

  void _cancel() {
    _cancelToken.cancel();
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.initialName != null;
    return AlertDialog(
      backgroundColor: Colors.grey.shade900,
      title: Text(isEdit ? 'Edit Playlist' : 'Add Playlist',
          style: const TextStyle(color: Colors.white)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _nameCtrl,
            style:      const TextStyle(color: Colors.white),
            decoration: _deco('Name (optional — auto-derived from URL)'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller:   _urlCtrl,
            style:        const TextStyle(color: Colors.white),
            decoration:   _deco('URL or filename (e.g. star.m3u)'),
            keyboardType: TextInputType.url,
            maxLines: 3, minLines: 1,
          ),
          const SizedBox(height: 6),
          const Text(
            'Enter a full URL or just a filename.\nFilenames are loaded from Documents/.',
            style: TextStyle(color: Colors.white38, fontSize: 11),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: _cancel,
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: _saving ? null : _save,
          child: Text(isEdit ? 'Save' : 'Add'),
        ),
      ],
    );
  }

  InputDecoration _deco(String label) => InputDecoration(
    labelText:   label,
    labelStyle:  const TextStyle(color: Colors.white54),
    enabledBorder: const UnderlineInputBorder(
        borderSide: BorderSide(color: Colors.white24)),
    focusedBorder: const UnderlineInputBorder(
        borderSide: BorderSide(color: Colors.blue)),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Simple cancellation token
// ─────────────────────────────────────────────────────────────────────────────

class _CancelToken {
  bool isCancelled = false;
  void cancel() => isCancelled = true;
}

// ─────────────────────────────────────────────────────────────────────────────
// _DpadSlider — replaces Flutter's Slider for remote/keyboard navigation.
//
// Flutter's Slider owns an internal FocusNode that unconditionally swallows
// ArrowUp/Down/Left/Right — no parent Focus wrapper can reliably intercept
// them because the Slider's child node handles them first.
//
// This widget uses a plain focusable Row with ◀ ▶ buttons instead.
// Left/Right = adjust value by one step. Up/Down = normal focus traversal.
// ─────────────────────────────────────────────────────────────────────────────

class _DpadSlider extends StatefulWidget {
  final double value;
  final double min;
  final double max;
  final int    divisions;
  final String label;     // already-formatted display string for current value
  final ValueChanged<double> onChanged;

  const _DpadSlider({
    super.key,
    required this.value,
    required this.min,
    required this.max,
    required this.divisions,
    required this.label,
    required this.onChanged,
  });

  @override
  State<_DpadSlider> createState() => _DpadSliderState();
}

class _DpadSliderState extends State<_DpadSlider> {
  final FocusNode _focus = FocusNode();

  @override
  void dispose() { _focus.dispose(); super.dispose(); }

  void _step(int direction) {
    if (widget.divisions == 0) return;
    final step = (widget.max - widget.min) / widget.divisions;
    final next = (widget.value + step * direction).clamp(widget.min, widget.max);
    if (next != widget.value) widget.onChanged(next);
  }

  KeyEventResult _onKey(FocusNode _, KeyEvent event) {
    if (event is! KeyDownEvent && event is! KeyRepeatEvent) {
      return KeyEventResult.ignored;
    }
    final key = event.logicalKey;
    if (key == LogicalKeyboardKey.arrowLeft)  { _step(-1); return KeyEventResult.handled; }
    if (key == LogicalKeyboardKey.arrowRight) { _step( 1); return KeyEventResult.handled; }
    // Up/Down: return ignored so the ListView's focus traversal handles them.
    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    final fraction = widget.divisions == 0 ? 0.0
        : ((widget.value - widget.min) / (widget.max - widget.min)).clamp(0.0, 1.0);

    return Focus(
      focusNode:       _focus,
      onKeyEvent:      _onKey,
      skipTraversal:   false,
      canRequestFocus: true,
      child: ListenableBuilder(listenable: _focus, builder: (ctx, _) {
        final focused = _focus.hasFocus;
        return GestureDetector(
          onTap: () => _focus.requestFocus(),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 120),
            margin:   const EdgeInsets.symmetric(vertical: 2),
            padding:  const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            decoration: BoxDecoration(
              color: focused ? Colors.blue.withOpacity(0.18) : Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: focused ? Colors.blue : Colors.transparent,
                width: 1.5,
              ),
            ),
            child: Row(
              children: [
                _StepBtn(icon: Icons.chevron_left,
                    enabled: widget.value > widget.min, focused: focused,
                    onTap: () => _step(-1)),
                const SizedBox(width: 6),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value:           fraction,
                      minHeight:       6,
                      backgroundColor: Colors.white12,
                      color: focused ? Colors.blue : Colors.blue.withOpacity(0.55),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                SizedBox(
                  width: 60,
                  child: Text(
                    widget.label,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color:      focused ? Colors.white : Colors.white60,
                      fontSize:   13,
                      fontWeight: focused ? FontWeight.bold : FontWeight.normal,
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                _StepBtn(icon: Icons.chevron_right,
                    enabled: widget.value < widget.max, focused: focused,
                    onTap: () => _step(1)),
              ],
            ),
          ),
        );
      }),
    );
  }
}

class _StepBtn extends StatelessWidget {
  final IconData icon;
  final bool enabled;
  final bool focused;
  final VoidCallback onTap;
  const _StepBtn({required this.icon, required this.enabled,
      required this.focused, required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: enabled ? onTap : null,
    borderRadius: BorderRadius.circular(6),
    child: Padding(
      padding: const EdgeInsets.all(4),
      child: Icon(icon, size: 22,
          color: !enabled ? Colors.white12
              : focused   ? Colors.blue
              :              Colors.white38),
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// _ChipSelectRow — focusable chip-style option selector.
// Left/Right cycle through options. Enter/Select also cycles.
// ─────────────────────────────────────────────────────────────────────────────

class _ChipSelectRow extends StatefulWidget {
  final List<String> options;
  final List<Color>? colors;   // optional per-chip accent colors
  final int selectedIndex;
  final ValueChanged<int> onChanged;

  const _ChipSelectRow({
    required this.options,
    required this.selectedIndex,
    required this.onChanged,
    this.colors,
  });

  @override
  State<_ChipSelectRow> createState() => _ChipSelectRowState();
}

class _ChipSelectRowState extends State<_ChipSelectRow> {
  final FocusNode _focus = FocusNode();

  @override
  void dispose() { _focus.dispose(); super.dispose(); }

  KeyEventResult _onKey(FocusNode _, KeyEvent event) {
    if (event is! KeyDownEvent && event is! KeyRepeatEvent) {
      return KeyEventResult.ignored;
    }
    final key = event.logicalKey;
    if (key == LogicalKeyboardKey.arrowLeft) {
      final next = (widget.selectedIndex - 1 + widget.options.length) % widget.options.length;
      widget.onChanged(next);
      return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.arrowRight ||
        key == LogicalKeyboardKey.enter ||
        key == LogicalKeyboardKey.select ||
        key == LogicalKeyboardKey.numpadEnter) {
      final next = (widget.selectedIndex + 1) % widget.options.length;
      widget.onChanged(next);
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) => Focus(
    focusNode:       _focus,
    onKeyEvent:      _onKey,
    skipTraversal:   false,
    canRequestFocus: true,
    child: ListenableBuilder(listenable: _focus, builder: (ctx, _) {
      final focused = _focus.hasFocus;
      return GestureDetector(
        onTap: () => _focus.requestFocus(),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
          decoration: BoxDecoration(
            color: focused ? Colors.blue.withOpacity(0.12) : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: focused ? Colors.blue : Colors.transparent,
              width: 1.5,
            ),
          ),
          child: Row(children: [
            for (int i = 0; i < widget.options.length; i++) ...[
              Expanded(child: _buildChip(i, focused)),
              if (i < widget.options.length - 1) const SizedBox(width: 4),
            ],
          ]),
        ),
      );
    }),
  );

  Widget _buildChip(int i, bool rowFocused) {
    final selected = i == widget.selectedIndex;
    final accent   = widget.colors != null ? widget.colors![i] : Colors.blue;
    return GestureDetector(
      onTap: () {
        _focus.requestFocus();
        widget.onChanged(i);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: selected ? accent.withOpacity(0.18) : Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: selected ? accent : (rowFocused ? Colors.white24 : Colors.white12),
            width: selected ? 2 : 1,
          ),
        ),
        child: Text(
          widget.options[i],
          textAlign: TextAlign.center,
          style: TextStyle(
            color: selected ? accent : (rowFocused ? Colors.white70 : Colors.white54),
            fontSize: 12,
            fontWeight: selected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
      ),
    );
  }
}

// Extension to avoid null/empty boilerplate
extension _StringExt on String {
  String ifEmpty(String fallback) => isEmpty ? fallback : this;
}
