// 26-03-28-1149
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/channel.dart';
import '../models/iptv_playlist.dart';
import '../services/playlist_service.dart';
import '../services/player_service.dart';

// ── Infrastructure ────────────────────────────────────────────────────────────

final sharedPrefsProvider = Provider<SharedPreferences>((_) {
  throw UnimplementedError('Override in main');
});

final playlistServiceProvider = Provider<PlaylistService>(
    (ref) => PlaylistService(ref.watch(sharedPrefsProvider)));

final playerServiceProvider = Provider<PlayerService>((ref) {
  final svc = PlayerService();
  ref.onDispose(svc.dispose);
  return svc;
});

// ── Playlists ─────────────────────────────────────────────────────────────────

class PlaylistsNotifier extends StateNotifier<List<IptvPlaylist>> {
  final PlaylistService _svc;
  PlaylistsNotifier(this._svc) : super(_svc.getAll());

  Future<IptvPlaylist> add(String name, String url) async {
    final p = await _svc.add(name, url);
    state = _svc.getAll();
    return p;
  }

  Future<void> delete(String id) async {
    await _svc.delete(id);
    state = _svc.getAll();
  }

  Future<IptvPlaylist> refresh(IptvPlaylist playlist) async {
    final updated = await _svc.refresh(playlist);
    state = _svc.getAll();
    return updated;
  }

  Future<IptvPlaylist> update(IptvPlaylist playlist) async {
    final updated = await _svc.update(playlist);
    state = _svc.getAll();
    return updated;
  }
}

final playlistsProvider =
    StateNotifierProvider<PlaylistsNotifier, List<IptvPlaylist>>(
        (ref) => PlaylistsNotifier(ref.watch(playlistServiceProvider)));

// ── Active playlist & channel ─────────────────────────────────────────────────

final activePlaylistIdProvider = StateProvider<String?>((ref) =>
    ref.watch(playlistServiceProvider).getActiveId());

final activePlaylistProvider = Provider<IptvPlaylist?>((ref) {
  final id = ref.watch(activePlaylistIdProvider);
  if (id == null) return null;
  try {
    return ref.watch(playlistsProvider).firstWhere((p) => p.id == id);
  } catch (_) {
    return null;
  }
});

final currentChannelProvider      = StateProvider<Channel?>((_) => null);
final currentChannelIndexProvider = StateProvider<int>((_) => 0);

// ── Update interval ───────────────────────────────────────────────────────────

final updateIntervalProvider = StateProvider<int>(
    (ref) => ref.watch(playlistServiceProvider).getInterval());

// ── Control mapping ───────────────────────────────────────────────────────────
// Values: 'up', 'down', 'left', 'right', 'tap'

class ControlMappingNotifier extends StateNotifier<Map<String, String>> {
  final SharedPreferences _prefs;

  static const _defaults = {
    'nextChannel': 'down',
    'prevChannel': 'up',
    'settings':    'right',
    'channelList': 'left',
  };

  ControlMappingNotifier(this._prefs) : super(_load(_prefs));

  static Map<String, String> _load(SharedPreferences prefs) {
    final m = <String, String>{};
    for (final k in _defaults.keys) {
      m[k] = prefs.getString('ctrl_$k') ?? _defaults[k]!;
    }
    return m;
  }

  Future<void> set(String action, String gesture) async {
    final updated = Map<String, String>.from(state);
    updated[action] = gesture;
    state = updated;
    await _prefs.setString('ctrl_$action', gesture);
  }

  String? conflictFor(String action, String gesture) {
    for (final entry in state.entries) {
      if (entry.key != action && entry.value == gesture) return entry.key;
    }
    return null;
  }
}

final controlMappingProvider =
    StateNotifierProvider<ControlMappingNotifier, Map<String, String>>(
        (ref) => ControlMappingNotifier(ref.watch(sharedPrefsProvider)));

// ── Tap behaviour ─────────────────────────────────────────────────────────────

class TapSettingsNotifier extends StateNotifier<Map<String, bool>> {
  final SharedPreferences _prefs;

  static const _defaults = {
    'toggleVideo': true,
    'pauseVideo':  true,
  };

  TapSettingsNotifier(this._prefs) : super(_load(_prefs));

  static Map<String, bool> _load(SharedPreferences prefs) {
    final m = <String, bool>{};
    for (final k in _defaults.keys) {
      m[k] = prefs.getBool('tap_$k') ?? _defaults[k]!;
    }
    return m;
  }

  Future<void> set(String key, bool value) async {
    final updated = Map<String, bool>.from(state);
    updated[key]  = value;
    state = updated;
    await _prefs.setBool('tap_$key', value);
  }
}

final tapSettingsProvider =
    StateNotifierProvider<TapSettingsNotifier, Map<String, bool>>(
        (ref) => TapSettingsNotifier(ref.watch(sharedPrefsProvider)));

// ── Display settings ──────────────────────────────────────────────────────────
// channelNameFontSize : double  (default 32)
// channelNameDuration : int     seconds (default 4)
// channelListHeight   : double  fraction of screen height (default 0.75)
// appFontScale        : double  text scale multiplier (default 1.0)
// swipeDeadZone       : double  fraction of screen height to ignore swipes at top & bottom (default 0.10)

class DisplaySettingsNotifier extends StateNotifier<Map<String, double>> {
  final SharedPreferences _prefs;

  static const _defaults = {
    'channelNameFontSize': 32.0,
    'channelNameDuration': 4.0,
    'channelListHeight':   0.75,
    'appFontScale':        1.0,
    'swipeDeadZone':       0.10,
  };

  DisplaySettingsNotifier(this._prefs) : super(_load(_prefs));

  static Map<String, double> _load(SharedPreferences prefs) {
    final m = <String, double>{};
    for (final k in _defaults.keys) {
      m[k] = prefs.getDouble('disp_$k') ?? _defaults[k]!;
    }
    return m;
  }

  Future<void> set(String key, double value) async {
    final updated = Map<String, double>.from(state);
    updated[key]  = value;
    state = updated;
    await _prefs.setDouble('disp_$key', value);
  }

  double get channelNameFontSize => state['channelNameFontSize'] ?? 32.0;
  int    get channelNameDuration => (state['channelNameDuration'] ?? 4.0).round();
  double get channelListHeight   => state['channelListHeight']   ?? 0.75;
  double get appFontScale        => state['appFontScale']        ?? 1.0;
  double get swipeDeadZone       => state['swipeDeadZone']       ?? 0.10;
  // Keep legacy accessors pointing to the unified value so existing call sites compile
  double get bottomDeadZone      => swipeDeadZone;
  double get topDeadZone         => swipeDeadZone;
}

final displaySettingsProvider =
    StateNotifierProvider<DisplaySettingsNotifier, Map<String, double>>(
        (ref) => DisplaySettingsNotifier(ref.watch(sharedPrefsProvider)));

// ── Auto-load M3U files ───────────────────────────────────────────────────────

final autoLoadM3uProvider = StateProvider<bool>(
    (ref) => ref.watch(playlistServiceProvider).getAutoLoadM3u());

// ── Subtitle settings ─────────────────────────────────────────────────────────

class SubtitleSettingsNotifier extends StateNotifier<Map<String, bool>> {
  final SharedPreferences _prefs;

  static const _defaults = {
    'showSubtitles': true,
  };

  SubtitleSettingsNotifier(this._prefs) : super(_load(_prefs));

  static Map<String, bool> _load(SharedPreferences prefs) {
    final m = <String, bool>{};
    for (final k in _defaults.keys) {
      m[k] = prefs.getBool('sub_$k') ?? _defaults[k]!;
    }
    return m;
  }

  Future<void> set(String key, bool value) async {
    final updated = Map<String, bool>.from(state);
    updated[key]  = value;
    state = updated;
    await _prefs.setBool('sub_$key', value);
  }

  bool get showSubtitles => state['showSubtitles'] ?? true;
}

final subtitleSettingsProvider =
    StateNotifierProvider<SubtitleSettingsNotifier, Map<String, bool>>(
        (ref) => SubtitleSettingsNotifier(ref.watch(sharedPrefsProvider)));

// ── Subtitle style ────────────────────────────────────────────────────────────
// fontSize     : double  (default 18.0 sp)
// colorIndex   : double  (0=white 1=yellow 2=cyan 3=green — default 1=yellow)
// outlineIndex : double  (0=none 1=outline 2=shadow — default 1)
// bottomOffset : double  (fraction of screen height from bottom — default 0.05)
// bold         : stored in SubtitleBoldNotifier below

class SubtitleStyleNotifier extends StateNotifier<Map<String, double>> {
  final SharedPreferences _prefs;

  static const _defaults = {
    'fontSize':     22.0,
    'colorIndex':   1.0,   // yellow
    'outlineIndex': 1.0,   // outline
    'bottomOffset': 0.05,  // 5% up from bottom
  };

  SubtitleStyleNotifier(this._prefs) : super(_load(_prefs));

  static Map<String, double> _load(SharedPreferences prefs) {
    final m = <String, double>{};
    for (final k in _defaults.keys) {
      m[k] = prefs.getDouble('subst_$k') ?? _defaults[k]!;
    }
    return m;
  }

  Future<void> set(String key, double value) async {
    final updated = Map<String, double>.from(state);
    updated[key]  = value;
    state = updated;
    await _prefs.setDouble('subst_$key', value);
  }

  double get fontSize     => state['fontSize']     ?? 22.0;
  int    get colorIndex   => (state['colorIndex']  ?? 1.0).round();
  int    get outlineIndex => (state['outlineIndex'] ?? 1.0).round();
  double get bottomOffset => state['bottomOffset'] ?? 0.05;
}

final subtitleStyleProvider =
    StateNotifierProvider<SubtitleStyleNotifier, Map<String, double>>(
        (ref) => SubtitleStyleNotifier(ref.watch(sharedPrefsProvider)));

// ── Subtitle bold ─────────────────────────────────────────────────────────────

class SubtitleBoldNotifier extends StateNotifier<bool> {
  final SharedPreferences _prefs;
  SubtitleBoldNotifier(this._prefs) : super(_prefs.getBool('subst_bold') ?? true);

  Future<void> set(bool value) async {
    state = value;
    await _prefs.setBool('subst_bold', value);
  }
}

final subtitleBoldProvider =
    StateNotifierProvider<SubtitleBoldNotifier, bool>(
        (ref) => SubtitleBoldNotifier(ref.watch(sharedPrefsProvider)));

// ── Playlist toast settings ───────────────────────────────────────────────────

class PlaylistToastNotifier extends StateNotifier<Map<String, bool>> {
  final SharedPreferences _prefs;

  static const _defaults = {
    'showToast': true,
  };

  PlaylistToastNotifier(this._prefs) : super(_load(_prefs));

  static Map<String, bool> _load(SharedPreferences prefs) {
    final m = <String, bool>{};
    for (final k in _defaults.keys) {
      m[k] = prefs.getBool('pltoast_$k') ?? _defaults[k]!;
    }
    return m;
  }

  Future<void> set(String key, bool value) async {
    final updated = Map<String, bool>.from(state);
    updated[key]  = value;
    state = updated;
    await _prefs.setBool('pltoast_$key', value);
  }

  bool get showToast => state['showToast'] ?? true;
}

final playlistToastProvider =
    StateNotifierProvider<PlaylistToastNotifier, Map<String, bool>>(
        (ref) => PlaylistToastNotifier(ref.watch(sharedPrefsProvider)));

// ── Toolbar button positions ──────────────────────────────────────────────────
// Each button gets a position 1–4 or 0 (disabled/hidden).
// Positions are 1-based slots shown left→right.
// 0 means the button is not shown in the toolbar.
//
// Buttons: nextChannel, nextPlaylist, settings, exit, prevChannel, prevPlaylist

class ToolbarLayoutNotifier extends StateNotifier<Map<String, int>> {
  final SharedPreferences _prefs;

  static const _defaults = {
    'nextChannel':  1,
    'nextPlaylist': 2,
    'settings':     3,
    'exit':         4,
    'prevChannel':  0,
    'prevPlaylist': 0,
  };

  ToolbarLayoutNotifier(this._prefs) : super(_load(_prefs));

  static Map<String, int> _load(SharedPreferences prefs) {
    final m = <String, int>{};
    for (final k in _defaults.keys) {
      m[k] = prefs.getInt('toolbar_$k') ?? _defaults[k]!;
    }
    return m;
  }

  Future<void> set(String button, int position) async {
    final updated = Map<String, int>.from(state);
    // If another button already occupies this position, displace it to 0
    if (position > 0) {
      for (final k in updated.keys) {
        if (k != button && updated[k] == position) {
          updated[k] = 0;
          await _prefs.setInt('toolbar_$k', 0);
        }
      }
    }
    updated[button] = position;
    state = updated;
    await _prefs.setInt('toolbar_$button', position);
  }

  /// Returns true if this button's slot conflicts with another.
  bool hasConflict(String button) {
    final pos = state[button] ?? 0;
    if (pos == 0) return false;
    return state.entries
        .where((e) => e.key != button && e.value == pos)
        .isNotEmpty;
  }

  /// Returns buttons ordered by position (enabled only).
  List<String> get orderedButtons {
    final enabled = state.entries
        .where((e) => e.value > 0)
        .toList()
      ..sort((a, b) => a.value.compareTo(b.value));
    return enabled.map((e) => e.key).toList();
  }
}

final toolbarLayoutProvider =
    StateNotifierProvider<ToolbarLayoutNotifier, Map<String, int>>(
        (ref) => ToolbarLayoutNotifier(ref.watch(sharedPrefsProvider)));

// ── Playlist switch channel start ─────────────────────────────────────────────
// 'first' = play first channel, 'last' = play last-played channel (if in list)

class PlaylistSwitchStartNotifier extends StateNotifier<String> {
  final SharedPreferences _prefs;
  PlaylistSwitchStartNotifier(this._prefs)
      : super(_prefs.getString('pl_switch_start') ?? 'first');

  Future<void> set(String value) async {
    state = value;
    await _prefs.setString('pl_switch_start', value);
  }
}

final playlistSwitchStartProvider =
    StateNotifierProvider<PlaylistSwitchStartNotifier, String>(
        (ref) => PlaylistSwitchStartNotifier(ref.watch(sharedPrefsProvider)));

// ── On playlist switch, hide channel list (default: on = hide) ───────────────

final playlistSwitchOpenChannelListProvider = StateNotifierProvider<_BoolPrefNotifier, bool>(
    (ref) => _BoolPrefNotifier(ref.watch(sharedPrefsProvider), 'pl_switch_open_list', true));

// ── Show playlist name on OSD ────────────────────────────────────────────────

final showPlaylistOnOsdProvider = StateNotifierProvider<_BoolPrefNotifier, bool>(
    (ref) => _BoolPrefNotifier(ref.watch(sharedPrefsProvider), 'osd_show_playlist', true));

// ── Generic bool pref notifier ───────────────────────────────────────────────

class _BoolPrefNotifier extends StateNotifier<bool> {
  final SharedPreferences _prefs;
  final String _key;
  _BoolPrefNotifier(this._prefs, this._key, bool defaultValue)
      : super(_prefs.getBool(_key) ?? defaultValue);

  Future<void> set(bool value) async {
    state = value;
    await _prefs.setBool(_key, value);
  }
}
