// 26-03-28-1839
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:media_kit/media_kit.dart' hide Playlist;
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'models/iptv_playlist.dart';
import 'providers/providers.dart';
import 'screens/player_screen.dart';
import 'screens/settings_screen.dart';
import 'services/playlist_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();

  // Hide system UI on Android (status bar + nav bar)
  if (Platform.isAndroid) {
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  final prefs = await SharedPreferences.getInstance();
  runApp(ProviderScope(
    overrides: [sharedPrefsProvider.overrideWithValue(prefs)],
    child: const EsPlayerApp(),
  ));
}

class EsPlayerApp extends ConsumerWidget {
  const EsPlayerApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scale = ref.watch(displaySettingsProvider.notifier).appFontScale;
    return MaterialApp(
      title: 'ES Player',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.dark(
          primary: Colors.blue,
          surface: Colors.grey.shade900,
        ),
        useMaterial3: true,
      ),
      // Apply app-wide font scale. Each screen inherits this automatically.
      // The channel name has its own absolute fontSize so it is unaffected.
      builder: (context, child) {
        final mq = MediaQuery.of(context);
        return MediaQuery(
          data: mq.copyWith(
            textScaler: TextScaler.linear(scale),
          ),
          child: child!,
        );
      },
      home: const _StartupScreen(),
    );
  }
}

class _StartupScreen extends ConsumerStatefulWidget {
  const _StartupScreen();
  @override
  ConsumerState<_StartupScreen> createState() => _StartupScreenState();
}

class _StartupScreenState extends ConsumerState<_StartupScreen>
    with WidgetsBindingObserver {
  bool _loading = false;
  String _status = '';
  DateTime? _wentToBackground;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _startup());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // ── App lifecycle: refresh playlist after waking from sleep ───────────────

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _wentToBackground = DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final bg = _wentToBackground;
      if (bg != null &&
          DateTime.now().difference(bg) > const Duration(minutes: 1)) {
        _refreshActivePlaylist();
      }
    }
  }

  Future<void> _refreshActivePlaylist() async {
    final svc = ref.read(playlistServiceProvider);
    final id = svc.getActiveId();
    if (id == null) return;
    final playlists = ref.read(playlistsProvider);
    IptvPlaylist? p;
    try { p = playlists.firstWhere((x) => x.id == id); } catch (_) { return; }
    try {
      await ref.read(playlistsProvider.notifier).refresh(p);
    } catch (_) {}
  }

  // ── Storage permission (Android) ──────────────────────────────────────────

  Future<void> _requestStoragePermission() async {
    // Android 13+ (API 33) replaced READ_EXTERNAL_STORAGE with granular
    // READ_MEDIA_* permissions. permission_handler's Permission.storage maps
    // to the old permission and is auto-granted but gives no real access on
    // API 33+. We request manageExternalStorage which covers Documents/.
    if (await Permission.manageExternalStorage.isGranted) return;

    // Try the legacy storage permission first (works on API < 33)
    final status = await Permission.storage.status;
    if (status.isGranted) return;

    if (status.isPermanentlyDenied) {
      _showPermissionSnackbar();
      return;
    }

    final result = await Permission.storage.request();
    if (result.isGranted) return;

    // On API 33+ the above may be ignored; try manageExternalStorage
    final manageStatus = await Permission.manageExternalStorage.status;
    if (manageStatus.isGranted) return;
    if (!manageStatus.isPermanentlyDenied) {
      await Permission.manageExternalStorage.request();
    }

    if (!await Permission.manageExternalStorage.isGranted &&
        !await Permission.storage.isGranted) {
      _showPermissionSnackbar();
    }
  }

  void _showPermissionSnackbar() {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Text(
        'Storage permission denied. '
        'Grant it in App Settings to load playlists from Documents/.',
      ),
      duration: const Duration(seconds: 6),
      action: SnackBarAction(label: 'Settings', onPressed: openAppSettings),
    ));
  }

  // ── Startup ───────────────────────────────────────────────────────────────

  Future<void> _startup() async {
    // 1. Request storage permission on Android so we can read Documents/
    if (Platform.isAndroid) {
      await _requestStoragePermission();
    }

    final svc = ref.read(playlistServiceProvider);

    // 2. Remove playlist entries whose local file was deleted
    try {
      await svc.removeOrphanedLocalPlaylists();
    } catch (e) {
      debugPrint('[startup] removeOrphanedLocalPlaylists error: $e');
    }

    // 3. Import from esplayer.txt
    try {
      await svc.importFromFile();
    } catch (e) {
      debugPrint('[startup] importFromFile error: $e');
    }

    // 4. Auto-load *.m3u / *.m3u8 files from Documents/ (if enabled)
    if (svc.getAutoLoadM3u()) {
      try {
        await svc.importM3uFiles();
      } catch (e) {
        debugPrint('[startup] importM3uFiles error: $e');
      }
    }

    // Read the final playlist list directly from the service — the source of
    // truth — rather than from the provider which may not have rebuilt yet.
    final playlists = svc.getAll();
    if (playlists.isEmpty) return;

    // Sync the provider state with what the service now has
    ref.invalidate(playlistsProvider);

    final activeId = svc.getActiveId();
    if (activeId == null) return;

    // Sync activePlaylistIdProvider in case import just set it
    ref.read(activePlaylistIdProvider.notifier).state = activeId;

    IptvPlaylist? active;
    try {
      active = playlists.firstWhere((p) => p.id == activeId);
    } catch (_) { return; }

    setState(() { _loading = true; _status = 'Updating playlist...'; });

    try {
      final refreshed =
          await ref.read(playlistsProvider.notifier).refresh(active!);
      final count = refreshed.channels.length;
      setState(() => _status = 'Updated — $count channels');
      await Future.delayed(const Duration(milliseconds: 600));
      active = refreshed;
    } catch (e) {
      // refresh() may have deleted the playlist (empty first fetch).
      // Re-read to check if it still exists.
      final stillExists = ref.read(playlistsProvider)
          .any((p) => p.id == active!.id);
      if (!stillExists) {
        setState(() { _loading = false; });
        return;
      }
      final cached = active!.channels.length;
      setState(() => _status = cached > 0
          ? 'Update failed — using $cached cached channels'
          : 'Playlist unavailable');
      await Future.delayed(const Duration(milliseconds: 1200));
    }

    if (active == null || active.channels.isEmpty) {
      setState(() { _loading = false; });
      return;
    }

    setState(() => _status = 'Starting stream...');

    final lastId = svc.getLastChannelId();
    int idx = 0;
    if (lastId != null) {
      final found = active.channels.indexWhere((c) => c.id == lastId);
      if (found != -1) {
        idx = found;
      } else {
        // FIX: the last-played channel was deleted from the playlist.
        // Reset to channel 0 and clear the stale id so we don't keep
        // looking for it on every subsequent launch.
        await svc.setLastChannelId(active.channels.first.id);
      }
    }

    final channel = active.channels[idx];
    ref.read(currentChannelProvider.notifier).state = channel;
    ref.read(currentChannelIndexProvider.notifier).state = idx;
    ref.read(activePlaylistIdProvider.notifier).state = activeId;

    // Enable wakelock when starting playback
    if (Platform.isAndroid || Platform.isIOS) {
      await WakelockPlus.enable();
    }

    await ref.read(playerServiceProvider).play(channel);
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const PlayerScreen()));

    // Background: refresh all other playlists so channels are in memory
    // when the user switches to them. Runs after navigation so it doesn't
    // block startup. Errors are silently ignored.
    _refreshOtherPlaylistsInBackground(activeId);
  }

  void _refreshOtherPlaylistsInBackground(String activeId) {
    Future.microtask(() async {
      final others = ref.read(playlistsProvider)
          .where((p) => p.id != activeId)
          .toList();
      for (final p in others) {
        if (!mounted) return;
        try {
          await ref.read(playlistsProvider.notifier).refresh(p);
        } catch (_) {}
        // Small delay between requests to avoid hammering the network
        await Future.delayed(const Duration(milliseconds: 500));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final playlists = ref.watch(playlistsProvider);
    if (playlists.isEmpty) return const SettingsScreen();
    if (_loading) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(
                  width: 48,
                  height: 48,
                  child: CircularProgressIndicator(
                      color: Colors.blue, strokeWidth: 3)),
              const SizedBox(height: 24),
              Text(_status,
                  style:
                      const TextStyle(color: Colors.white70, fontSize: 15),
                  textAlign: TextAlign.center),
            ],
          ),
        ),
      );
    }
    return const SettingsScreen();
  }
}
