// 26-03-28-1603
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/iptv_playlist.dart';
import '../models/channel.dart';
import 'm3u_parser.dart';

class PlaylistService {
  static const _playlistsKey    = 'playlists_v1';
  static const _activeIdKey     = 'active_playlist_id';
  static const _lastChannelKeyPrefix = 'last_channel_id_';
  static const _intervalKey     = 'update_interval_minutes';
  static const _importedFileKey  = 'esplayer_imported_urls';
  static const _deletedFileKey   = 'esplayer_deleted_urls';
  static const defaultInterval  = 60;

  final SharedPreferences _prefs;
  PlaylistService(this._prefs);

  // ── Path helpers ──────────────────────────────────────────────────────────

  /// Path to the playlist list file (Documents/esplayer.txt).
  static String getEsPlayerPath() {
    final home = Platform.environment['HOME'] ?? '';
    if (Platform.isWindows) {
      final userProfile = Platform.environment['USERPROFILE'] ?? home;
      return '$userProfile\\Documents\\esplayer.txt';
    } else if (Platform.isAndroid) {
      return '/storage/emulated/0/Documents/esplayer.txt';
    } else if (Platform.isMacOS) {
      return '$home/Documents/esplayer.txt';
    } else {
      return '$home/Documents/esplayer.txt';
    }
  }

  /// Returns the Documents directory path for the current platform.
  /// On Android we try both 'Documents' and 'documents' since some devices
  /// use lowercase. Returns whichever exists, defaulting to 'Documents'.
  static Future<String> getDocumentsDirAsync() async {
    if (Platform.isAndroid) {
      const upper = '/storage/emulated/0/Documents';
      const lower = '/storage/emulated/0/documents';
      if (await Directory(lower).exists()) return lower;
      return upper; // default even if it doesn't exist yet
    }
    return getDocumentsDir();
  }

  /// Synchronous version — always returns 'Documents' (uppercase).
  /// Use getDocumentsDirAsync() when you need the correct casing.
  static String getDocumentsDir() {
    final home = Platform.environment['HOME'] ?? '';
    if (Platform.isWindows) {
      final userProfile = Platform.environment['USERPROFILE'] ?? home;
      return '$userProfile\\Documents';
    } else if (Platform.isAndroid) {
      return '/storage/emulated/0/Documents';
    } else {
      return '$home/Documents';
    }
  }

  /// Resolves a playlist URL or bare filename entered by the user.
  /// If the value looks like a bare filename (no scheme, no path separator),
  /// treat it as a file inside Documents/.
  /// Returns the resolved URL/path string, or null if the file doesn't exist.
  static Future<String?> resolvePlaylistUrl(String raw) async {
    final trimmed = raw.trim();
    if (trimmed.isEmpty) return null;

    // Already a proper URL
    if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
      return trimmed;
    }

    // Bare filename like "star.m3u" — look in Documents/ (correct casing)
    final sep      = Platform.isWindows ? '\\' : '/';
    final docsDir  = await getDocumentsDirAsync();
    final fullPath = '$docsDir$sep$trimmed';
    if (await File(fullPath).exists()) return fullPath;

    // Try as absolute path
    if (await File(trimmed).exists()) return trimmed;

    return null;
  }

  /// Removes playlist entries whose URL is a local file that no longer exists.
  /// Returns the number removed.
  Future<int> removeOrphanedLocalPlaylists() async {
    final all     = getAll();
    final orphans = <String>[];
    for (final p in all) {
      if (!p.url.startsWith('http')) {
        if (!await File(p.url).exists()) orphans.add(p.id);
      }
    }
    // FIX: clear active/lastChannel prefs when the active playlist is orphaned
    final activeId = getActiveId();
    for (final id in orphans) {
      all.removeWhere((p) => p.id == id);
      if (activeId == id) {
        await _prefs.remove(_activeIdKey);
        await _prefs.remove('last_channel_id');
      }
    }
    if (orphans.isNotEmpty) await _saveAll(all);
    return orphans.length;
  }



  bool getAutoLoadM3u() => _prefs.getBool('auto_load_m3u') ?? true;
  Future<void> setAutoLoadM3u(bool v) => _prefs.setBool('auto_load_m3u', v);

  /// Scans Documents/ for *.m3u and *.m3u8 files that are not already in the
  /// playlist list, and adds them. Returns the number of new playlists added.
  Future<int> importM3uFiles() async {
    final docsDir = await getDocumentsDirAsync();
    final dir     = Directory(docsDir);
    if (!await dir.exists()) return 0;

    final all          = getAll();
    final existingUrls = all.map((p) => p.url).toSet();
    final alreadyImported =
        (_prefs.getStringList(_importedFileKey) ?? []).toSet();

    int added = 0;

    List<FileSystemEntity> entries;
    try {
      entries = await dir.list().toList();
    } catch (_) {
      return 0;
    }

    for (final entry in entries) {
      if (entry is! File) continue;
      final path      = entry.path;
      final fileName  = path.split(Platform.isWindows ? '\\' : '/').last;
      final lowerName = fileName.toLowerCase();

      // Only pick up .m3u and .m3u8 files
      if (!lowerName.endsWith('.m3u') && !lowerName.endsWith('.m3u8')) continue;

      // Skip if already tracked or explicitly deleted by user
      final pathLower = path.toLowerCase();
      final deletedUrls = (_prefs.getStringList(_deletedFileKey) ?? []).toSet();
      if (existingUrls.any((u) => u.toLowerCase() == pathLower) ||
          alreadyImported.any((u) => u.toLowerCase() == pathLower) ||
          deletedUrls.any((u) => u.toLowerCase() == pathLower)) continue;

      final rawName = fileName
          .replaceAll(RegExp(r'\.(m3u8?)$', caseSensitive: false), '')
          .replaceAll('_', ' ')
          .trim();
      final name = rawName.isEmpty ? 'Playlist ${added + 1}' : rawName;

      final p = IptvPlaylist(
        id:   '${DateTime.now().millisecondsSinceEpoch}_${path.hashCode.abs()}',
        name: name,
        url:  path,
      );
      all.add(p);
      alreadyImported.add(path);
      added++;
    }

    if (added > 0) {
      await _saveAll(all);
      await _prefs.setStringList(_importedFileKey, alreadyImported.toList());
      if (getActiveId() == null && all.isNotEmpty) {
        await setActiveId(all.first.id);
      }
    }

    return added;
  }



  /// Reads Documents/esplayer.txt, imports any new entries as playlists.
  /// Each line may be a URL or a bare filename (resolved against Documents/).
  /// Returns the number of new playlists added.
  Future<int> importFromFile() async {
    // Try to find esplayer.txt using the correct-cased Documents path
    final docsDir = await getDocumentsDirAsync();
    final sep     = Platform.isWindows ? '\\' : '/';

    // Try both casings of the filename just in case
    File? file;
    for (final name in ['esplayer.txt', 'Esplayer.txt']) {
      final candidate = File('$docsDir$sep$name');
      if (await candidate.exists()) { file = candidate; break; }
    }
    if (file == null) return 0;

    String content;
    try {
      content = await file.readAsString();
    } catch (_) {
      return 0;
    }

    final lines = content
        .split('\n')
        .map((l) => l.trim())
        .where((l) => l.isNotEmpty && !l.startsWith('#'))
        .toList();

    if (lines.isEmpty) return 0;

    final alreadyImported =
        (_prefs.getStringList(_importedFileKey) ?? []).toSet();
    final all          = getAll();
    final existingUrls = all.map((p) => p.url).toSet();

    int added = 0;
    for (final line in lines) {
      // Resolve to a usable URL/path
      final resolved = await resolvePlaylistUrl(line);
      if (resolved == null) continue;

      // Skip if already imported by this resolved path
      if (alreadyImported.contains(resolved) ||
          existingUrls.contains(resolved)) continue;

      // Derive a friendly name
      String name;
      if (resolved.startsWith('http')) {
        final uri = Uri.tryParse(resolved);
        name = uri != null
            ? (uri.pathSegments.lastWhere((s) => s.isNotEmpty,
                orElse: () => uri.host))
            : resolved;
      } else {
        name = resolved.split(Platform.isWindows ? '\\' : '/').last;
      }
      name = name
          .replaceAll(RegExp(r'\.(m3u8?|txt)$', caseSensitive: false), '')
          .replaceAll('_', ' ')
          .trim();
      if (name.isEmpty) name = 'Playlist ${added + 1}';

      final p = IptvPlaylist(
        id:   '${DateTime.now().millisecondsSinceEpoch}_${resolved.hashCode.abs()}',
        name: name,
        url:  resolved,
      );
      all.add(p);
      alreadyImported.add(resolved);
      added++;
    }

    if (added > 0) {
      await _saveAll(all);
      await _prefs.setStringList(_importedFileKey, alreadyImported.toList());
      if (getActiveId() == null && all.isNotEmpty) {
        await setActiveId(all.first.id);
      }
    }

    return added;
  }

  // ── Playlists ─────────────────────────────────────────────────────────────

  List<IptvPlaylist> getAll() {
    final raw = _prefs.getStringList(_playlistsKey) ?? [];
    return raw
        .map((s) =>
            IptvPlaylist.fromJson(jsonDecode(s) as Map<String, dynamic>))
        .toList();
  }

  Future<void> _saveAll(List<IptvPlaylist> list) async {
    await _prefs.setStringList(
        _playlistsKey, list.map((p) => jsonEncode(p.toJson())).toList());
  }

  Future<IptvPlaylist> add(String name, String url) async {
    final all = getAll();
    final p   = IptvPlaylist(
      id:   DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
      url:  url,
    );
    all.add(p);
    await _saveAll(all);
    return p;
  }

  Future<void> delete(String id) async {
    final all = getAll();
    IptvPlaylist? target;
    try { target = all.firstWhere((p) => p.id == id); } catch (_) {}
    all.removeWhere((p) => p.id == id);
    await _saveAll(all);
    // FIX: also clear the last-channel pref so a stale channel id from the
    // deleted playlist doesn't confuse _startup() on the next launch.
    if (getActiveId() == id) {
      await _prefs.remove(_activeIdKey);
      await _prefs.remove('last_channel_id');
    }
    // Add local file to blocklist so auto-import never re-adds it on restart
    if (target != null && !target.url.startsWith('http')) {
      final deleted = (_prefs.getStringList(_deletedFileKey) ?? []).toSet();
      deleted.add(target.url);
      await _prefs.setStringList(_deletedFileKey, deleted.toList());
    }
  }

  Future<IptvPlaylist> update(IptvPlaylist playlist) async {
    final all = getAll();
    final idx = all.indexWhere((p) => p.id == playlist.id);
    if (idx != -1) all[idx] = playlist; else all.add(playlist);
    await _saveAll(all);
    return playlist;
  }

  // ── Active / last channel ─────────────────────────────────────────────────

  String? getActiveId() => _prefs.getString(_activeIdKey);
  Future<void> setActiveId(String id) => _prefs.setString(_activeIdKey, id);

  /// Returns the last-played channel id for a specific playlist.
  /// Falls back to the legacy global key for backwards compatibility.
  String? getLastChannelId({String? playlistId}) {
    if (playlistId != null) {
      final perPlaylist = _prefs.getString('$_lastChannelKeyPrefix$playlistId');
      if (perPlaylist != null) return perPlaylist;
    }
    // Legacy fallback
    return _prefs.getString('last_channel_id');
  }

  Future<void> setLastChannelId(String channelId, {String? playlistId}) async {
    if (playlistId != null) {
      await _prefs.setString('$_lastChannelKeyPrefix$playlistId', channelId);
    }
    // Also write legacy key so startup code still works
    await _prefs.setString('last_channel_id', channelId);
  }

  // ── Update interval ───────────────────────────────────────────────────────

  int  getInterval()             => _prefs.getInt(_intervalKey) ?? defaultInterval;
  Future<void> setInterval(int m) => _prefs.setInt(_intervalKey, m);

  bool needsRefresh(IptvPlaylist p) {
    if (p.lastUpdated == null) return true;
    return DateTime.now().difference(p.lastUpdated!) >=
        Duration(minutes: getInterval());
  }

  /// Validates that a URL or local file is accessible before adding it.
  /// Throws a descriptive exception if not reachable.
  static Future<void> validateUrl(String url) async {
    if (!url.startsWith('http')) {
      // Local file
      final file = File(url);
      if (!await file.exists()) {
        throw Exception('File not found: $url');
      }
      return;
    }
    // Remote URL: do a HEAD first (fast), fall back to GET with limit
    try {
      final uri = Uri.parse(url);
      http.Response res;
      try {
        res = await http
            .head(uri)
            .timeout(const Duration(seconds: 10));
      } catch (_) {
        // Some servers don't support HEAD; try GET with byte limit
        final req = http.Request('GET', uri);
        final client = http.Client();
        try {
          final stream = await client.send(req)
              .timeout(const Duration(seconds: 10));
          await stream.stream.first; // just read first chunk
          res = http.Response('', stream.statusCode);
        } finally {
          client.close();
        }
      }
      if (res.statusCode >= 400) {
        throw Exception('Server returned ${res.statusCode}');
      }
    } on Exception {
      rethrow;
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }



  /// Writes [channels] as an M3U file to Documents/ and adds it as a playlist.
  /// Name format: "{playlistName}-{term} ({count} channels)"
  /// File name: "{playlistName}-{term}.m3u"  (spaces→underscores, sanitised)
  Future<IptvPlaylist> saveSearchAsPlaylist({
    required String playlistName,
    required String searchTerm,
    required List<Channel> channels,
  }) async {
    final docsDir  = await getDocumentsDirAsync();
    final sep      = Platform.isWindows ? '\\' : '/';

    // Sanitise for filename
    final safeName = playlistName
        .replaceAll(RegExp(r'[^\w\-]'), '_')
        .replaceAll(RegExp(r'_+'), '_');
    final safeTerm = searchTerm
        .replaceAll(RegExp(r'[^\w\-]'), '_')
        .replaceAll(RegExp(r'_+'), '_');
    final fileName = '$safeName-$safeTerm.m3u';
    final filePath = '$docsDir$sep$fileName';

    // Write M3U
    final buf = StringBuffer('#EXTM3U\n');
    for (final ch in channels) {
      buf.write('#EXTINF:-1');
      if (ch.logoUrl != null && ch.logoUrl!.isNotEmpty) {
        buf.write(' tvg-logo="${ch.logoUrl}"');
      }
      buf.write(',${ch.name}\n');
      if (ch.userAgent != null) {
        buf.write('#EXTVLCOPT:http-user-agent=${ch.userAgent}\n');
      }
      if (ch.referrer != null) {
        buf.write('#EXTVLCOPT:http-referrer=${ch.referrer}\n');
      }
      if (ch.isEncrypted) {
        buf.write('#KODIPROP:inputstream.adaptive.license_type=clearkey\n');
        final keyStr = ch.clearKeys
            .map((e) => '${e.keyId}:${e.key}')
            .join(',');
        buf.write('#KODIPROP:inputstream.adaptive.license_key=$keyStr\n');
      }
      buf.write('${ch.url}\n');
    }

    await File(filePath).writeAsString(buf.toString());

    // Human-readable playlist name
    final friendlyName =
        '$playlistName-$searchTerm (${channels.length} channels)';

    return add(friendlyName, filePath);
  }

  // ── Fetch ─────────────────────────────────────────────────────────────────

  Future<List<Channel>> fetchChannels(String url) async {
    // Local file path
    if (!url.startsWith('http')) {
      final file = File(url);
      if (!await file.exists()) throw Exception('File not found: $url');
      return M3uParser.parse(await file.readAsString());
    }
    final res =
        await http.get(Uri.parse(url)).timeout(const Duration(seconds: 30));
    if (res.statusCode != 200) throw Exception('HTTP ${res.statusCode}');
    return M3uParser.parse(res.body);
  }

  Future<IptvPlaylist> refresh(IptvPlaylist playlist) async {
    final channels = await fetchChannels(playlist.url);
    return update(playlist.copyWith(
      channels:    channels,
      lastUpdated: DateTime.now(),
    ));
  }
}
