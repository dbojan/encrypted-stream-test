// lib/services/m3u_parser.dart
import 'dart:convert';
import '../models/channel.dart';

class M3uParser {
  static List<Channel> parse(String content) {
    final channels = <Channel>[];
    final lines = content
        .replaceAll('\r\n', '\n')
        .replaceAll('\r', '\n')
        .split('\n')
        .map((l) => l.trim())
        .toList();

    String? name;
    String? logoUrl;
    String? userAgent;
    String? referrer;
    String? licenseKey;
    bool isClearKey = false;

    for (final line in lines) {
      if (line.startsWith('#EXTINF:')) {
        name = _parseName(line);
        logoUrl = _parseAttr(line, 'tvg-logo');
        userAgent = null;
        referrer = null;
        licenseKey = null;
        isClearKey = false;
      } else if (line.startsWith('#EXTVLCOPT:http-user-agent=')) {
        userAgent = line.substring('#EXTVLCOPT:http-user-agent='.length).trim();
      } else if (line.startsWith('#EXTVLCOPT:http-referrer=')) {
        referrer = line.substring('#EXTVLCOPT:http-referrer='.length).trim();
      } else if (line.startsWith('#KODIPROP:inputstream.adaptive.license_type=clearkey')) {
        isClearKey = true;
      } else if (line.startsWith('#KODIPROP:inputstream.adaptive.license_key=')) {
        licenseKey = line
            .substring('#KODIPROP:inputstream.adaptive.license_key='.length)
            .trim();
      } else if (!line.startsWith('#') && line.isNotEmpty && name != null) {
        final url = line;
        final keys = isClearKey && licenseKey != null
            ? _parseClearKeys(licenseKey!)
            : <ClearKeyEntry>[];

        channels.add(Channel(
          id: url.hashCode.abs().toString(),
          name: name!,
          url: url,
          logoUrl: logoUrl,
          userAgent: userAgent,
          referrer: referrer,
          clearKeys: keys,
        ));

        name = null;
        logoUrl = null;
        userAgent = null;
        referrer = null;
        licenseKey = null;
        isClearKey = false;
      }
    }

    return channels;
  }

  static List<ClearKeyEntry> _parseClearKeys(String raw) {
    final trimmed = raw.trim();
    if (trimmed.startsWith('{') && trimmed.contains('"')) {
      return _parseJsonKeys(trimmed);
    }
    final inner = trimmed.startsWith('{') && trimmed.endsWith('}')
        ? trimmed.substring(1, trimmed.length - 1)
        : trimmed;
    return _parseColonPairs(inner);
  }

  static List<ClearKeyEntry> _parseJsonKeys(String json) {
    try {
      final map = jsonDecode(json) as Map<String, dynamic>;
      return map.entries
          .map((e) => ClearKeyEntry(keyId: e.key.trim(), key: (e.value as String).trim()))
          .toList();
    } catch (_) {
      final cleaned = json.replaceAll('"', '').replaceAll('{', '').replaceAll('}', '');
      return _parseColonPairs(cleaned);
    }
  }

  static List<ClearKeyEntry> _parseColonPairs(String pairs) {
    return pairs
        .split(',')
        .map((pair) {
          final parts = pair.trim().split(':');
          if (parts.length == 2) {
            return ClearKeyEntry(keyId: parts[0].trim(), key: parts[1].trim());
          }
          return null;
        })
        .whereType<ClearKeyEntry>()
        .toList();
  }

  static String _parseName(String extinf) {
    final i = extinf.lastIndexOf(',');
    return i != -1 ? extinf.substring(i + 1).trim() : 'Unknown';
  }

  static String? _parseAttr(String line, String attr) {
    final m = RegExp('$attr="([^"]*)"').firstMatch(line);
    return m?.group(1);
  }
}
