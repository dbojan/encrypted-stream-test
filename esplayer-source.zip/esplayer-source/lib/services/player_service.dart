// lib/services/player_service.dart
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../models/channel.dart';

class PlayerService {
  static const _ch = MethodChannel('com.esplayer.es_player/player');

  late final Player _player;
  late final VideoController videoController;
  WebViewController? webViewController;

  bool get isAndroid => Platform.isAndroid;
  bool get isDesktop => Platform.isLinux || Platform.isWindows;

  PlayerService() {
    _player = Player();
    videoController = VideoController(_player);
    if (isDesktop) {
      webViewController = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setBackgroundColor(const Color(0xFF000000))
        ..loadHtmlString('<html><body style="background:#000"></body></html>');
    }
  }

  Stream<bool> get playingStream => _player.stream.playing;
  Stream<String> get errorStream => _player.stream.error;

  Future<void> play(Channel channel, {
    bool showSubtitles = true,
    double subtitleFontSize = 18.0,
    int subtitleColorIndex = 1,
    int subtitleOutlineIndex = 1,
    bool subtitleBold = false,
    double subtitleBottomOffset = 0.12,
  }) async {
    if (isAndroid) {
      await _ch.invokeMethod('play', {
        'url': channel.url,
        'clearKeys': channel.clearKeyMap,
        if (channel.userAgent != null) 'userAgent': channel.userAgent,
        if (channel.referrer != null) 'referrer': channel.referrer,
        'showSubtitles':         showSubtitles,
        'subtitleFontSize':      subtitleFontSize,
        'subtitleColorIndex':    subtitleColorIndex,
        'subtitleOutlineIndex':  subtitleOutlineIndex,
        'subtitleBold':          subtitleBold,
        'subtitleBottomOffset':  subtitleBottomOffset,
      });
    } else {
      if (channel.isEncrypted) {
        final html = _buildShakaHtml(channel.url, channel.clearKeyMap);
        await webViewController?.loadHtmlString(html);
      } else {
        await _player.stop();
        final extras = <String, String>{};
        if (channel.userAgent != null) extras['user-agent'] = channel.userAgent!;
        if (channel.referrer != null) extras['referrer'] = channel.referrer!;
        await _player.open(Media(channel.url, extras: extras.isEmpty ? null : extras));
      }
    }
  }

  Future<void> stop() async {
    if (isAndroid) {
      await _ch.invokeMethod('stop');
    } else {
      await _player.stop();
      await webViewController?.loadHtmlString(
          '<html><body style="background:#000"></body></html>');
    }
  }

  Future<void> togglePlayPause() async {
    if (isAndroid) {
      await _ch.invokeMethod('togglePlayPause');
    } else {
      await _player.playOrPause();
    }
  }

  /// Pauses only if currently playing. Does nothing if already paused.
  Future<void> pauseIfPlaying() async {
    if (isAndroid) {
      await _ch.invokeMethod('pauseIfPlaying');
    } else {
      if (_player.state.playing) await _player.pause();
    }
  }

  /// Hide or show the video surface (Android only).
  Future<void> setVideoVisible(bool visible) async {
    if (isAndroid) {
      await _ch.invokeMethod('setVisible', {'visible': visible});
    }
  }

  /// Hide or show the subtitle overlay (Android only).
  Future<void> setSubtitleVisible(bool visible) async {
    if (isAndroid) {
      await _ch.invokeMethod('setSubtitleVisible', {'visible': visible});
    }
  }

  /// Apply subtitle style changes live without restarting the channel.
  Future<void> setSubtitleStyle({
    double? fontSize,
    int? colorIndex,
    int? outlineIndex,
    bool? bold,
    double? bottomOffset,
  }) async {
    if (isAndroid) {
      await _ch.invokeMethod('setSubtitleStyle', {
        if (fontSize      != null) 'subtitleFontSize':     fontSize,
        if (colorIndex    != null) 'subtitleColorIndex':   colorIndex,
        if (outlineIndex  != null) 'subtitleOutlineIndex': outlineIndex,
        if (bold          != null) 'subtitleBold':         bold,
        if (bottomOffset  != null) 'subtitleBottomOffset': bottomOffset,
      });
    }
  }

  /// Re-apply aspect ratio after navigation (Android only).
  Future<void> reapplyAspectRatio() async {
    if (isAndroid) {
      await _ch.invokeMethod('reapplyAspectRatio');
    }
  }

  void dispose() {
    _player.dispose();
  }

  String _buildShakaHtml(String streamUrl, Map<String, String> clearKeys) {
    String drmConfig = '';
    if (clearKeys.isNotEmpty) {
      final keyObjects = clearKeys.entries
          .map((e) =>
              '{"kty":"oct","kid":"${_hexToBase64Url(e.key)}","k":"${_hexToBase64Url(e.value)}"}')
          .join(',');
      final licenseJson = '{"keys":[$keyObjects],"type":"temporary"}';
      final licenseB64 = base64.encode(utf8.encode(licenseJson));
      drmConfig = '''
        player.configure({
          drm: { servers: { 'org.w3.clearkey': 'data:application/json;base64,$licenseB64' } }
        });
      ''';
    }

    return '''<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { background:#000; width:100vw; height:100vh; overflow:hidden; }
    video { width:100%; height:100%; object-fit:contain; }
  </style>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/shaka-player/4.7.11/shaka-player.compiled.js"></script>
</head>
<body>
  <video id="v" autoplay playsinline></video>
  <script>
    async function init() {
      if (!shaka.Player.isBrowserSupported()) return;
      const player = new shaka.Player();
      await player.attach(document.getElementById('v'));
      player.addEventListener('error', e => {
        if (typeof EsPlayer !== 'undefined') EsPlayer.postMessage('error:' + e.detail.code);
      });
      $drmConfig
      try {
        await player.load('$streamUrl');
        document.getElementById('v').play();
        if (typeof EsPlayer !== 'undefined') EsPlayer.postMessage('playing');
      } catch(e) {
        if (typeof EsPlayer !== 'undefined') EsPlayer.postMessage('error:' + e.message);
      }
    }
    init();
  </script>
</body>
</html>''';
  }

  String _hexToBase64Url(String hex) {
    final bytes = <int>[];
    for (int i = 0; i < hex.length; i += 2) {
      bytes.add(int.parse(hex.substring(i, i + 2), radix: 16));
    }
    return base64Url.encode(bytes).replaceAll('=', '');
  }
}
