// 26-03-28-1714
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/channel.dart';
import '../models/iptv_playlist.dart';

class ChannelList extends StatefulWidget {
  final List<Channel> channels;
  final String? currentChannelId;
  final void Function(Channel channel, int index) onTap;
  final bool tvMode;
  final ScrollController? scrollController;
  final bool scrollToCurrentOnBuild;

  /// All available playlists for the selector header.
  /// Pass null or a single-item list to hide arrows.
  final List<IptvPlaylist>? playlists;
  final int activePlaylistIndex;
  final void Function(IptvPlaylist playlist)? onPlaylistChanged;

  final String? playlistName;
  final void Function(String term, List<Channel> channels)? onSaveSearch;
  final void Function(String term, List<Channel> filtered)? onSearchChanged;
  final String initialSearchTerm;

  /// Called when the user taps the close (✕) button in the header.
  final VoidCallback? onClose;

  /// Called when the list is empty and needs a refresh.
  final void Function(IptvPlaylist playlist)? onRefreshPlaylist;

  final bool navigateFilteredList;
  final void Function(Channel channel, int fullIndex)? onNext;
  final void Function(Channel channel, int fullIndex)? onPrev;

  /// Called when the user presses Back/Escape/Backspace while the list is focused.
  final VoidCallback? onBack;

  /// Optional external FocusNode to use for the list's key handler.
  /// When provided, the ChannelList will not create its own FocusNode,
  /// so the caller can requestFocus() on it directly without a double-hop.
  final FocusNode? externalFocusNode;

  /// Ordered list of callbacks for the bottom bar buttons (left→right).
  /// Used for D-pad Right navigation from the channel list.
  final List<VoidCallback>? bottomBarActions;

  /// Called whenever the D-pad focus moves into/within the bottom bar zone.
  /// index = focused button index, or -1 when leaving bottom bar zone.
  final void Function(int index)? onBottomBarFocusChanged;

  const ChannelList({
    super.key,
    required this.channels,
    required this.onTap,
    this.currentChannelId,
    this.tvMode = false,
    this.scrollController,
    this.scrollToCurrentOnBuild = false,
    this.playlists,
    this.activePlaylistIndex = 0,
    this.onPlaylistChanged,
    this.playlistName,
    this.onSaveSearch,
    this.onSearchChanged,
    this.initialSearchTerm = '',
    this.onClose,
    this.onRefreshPlaylist,
    this.navigateFilteredList = false,
    this.onNext,
    this.onPrev,
    this.onBack,
    this.externalFocusNode,
    this.bottomBarActions,
    this.onBottomBarFocusChanged,
  });

  @override
  State<ChannelList> createState() => _ChannelListState();
}


enum _FocusZone { list, header, bottomBar }

class _ChannelListState extends State<ChannelList> {
  late final ScrollController _sc;
  bool _ownsController = false;
  bool _showMoreIndicator = false;

  // ── D-pad / keyboard focus zone ──────────────────────────────────────────
  // Zone:   list      = channel items (Up/Down navigate)
  //         header    = playlist selector row buttons (Left/Right navigate)
  //         bottomBar = bottom icon bar buttons (Left/Right navigate)
  // Left from list  → header zone,     Right from list → bottomBar zone
  // Up   from list  → list zone stays, Down from list  → list zone stays
  // Back / Escape / Backspace always closes the list.
  _FocusZone _zone = _FocusZone.list;
  int _focusedIndex = -1;       // index in filtered channel list
  int _headerFocusIdx  = 0;     // index in header button list
  int _bottomBarFocusIdx = 0;   // index in bottom bar button list

  // Header button actions in left→right order.
  // Filled by ChannelList from widget callbacks when the list is open.
  // Order: [prevPlaylist?, close, refresh, nextPlaylist?]
  List<VoidCallback> _headerActions = [];
  List<VoidCallback> _bottomBarActions = [];

  FocusNode? _ownedListFocus;
  FocusNode get _listFocus => widget.externalFocusNode ?? _ownedListFocus!;

  final TextEditingController _searchCtrl = TextEditingController();
  String _searchTerm = '';

  // ── Filtered list ──────────────────────────────────────────────────────────

  List<Channel> _applyFilter(String term) {
    if (term.isEmpty) return widget.channels;
    final lower = term.toLowerCase();
    return widget.channels
        .where((c) => c.name.toLowerCase().contains(lower))
        .toList();
  }

  List<Channel> get _filtered => _applyFilter(_searchTerm);

  /// Index of the current channel within the filtered list (-1 if not found).
  int get _currentFilteredIndex {
    final id = widget.currentChannelId;
    if (id == null) return -1;
    return _filtered.indexWhere((c) => c.id == id);
  }

  // ── Lifecycle ──────────────────────────────────────────────────────────────

  @override
  void initState() {
    super.initState();
    if (widget.externalFocusNode == null) {
      _ownedListFocus = FocusNode();
    }
    if (widget.scrollController != null) {
      _sc = widget.scrollController!;
      _ownsController = false;
    } else {
      _sc = ScrollController();
      _ownsController = true;
    }
    _searchCtrl.addListener(() {
      final term     = _searchCtrl.text;
      final filtered = _applyFilter(term);
      setState(() {
        _searchTerm   = term;
        // Reset focused index: prefer current channel, else first item
        final cur = filtered.indexWhere((c) => c.id == widget.currentChannelId);
        _focusedIndex = cur >= 0 ? cur : (filtered.isNotEmpty ? 0 : -1);
      });
      widget.onSearchChanged?.call(term, filtered);
      WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToCurrent());
    });
    // Restore persisted search term if provided
    if (widget.initialSearchTerm.isNotEmpty) {
      _searchCtrl.text = widget.initialSearchTerm;
      _searchTerm      = widget.initialSearchTerm;
    }
    // Set initial focused index to the currently playing channel
    _focusedIndex = _currentFilteredIndex;
    // If not found (e.g. search active), start at 0 so first Down goes to item 1
    // rather than needing two presses to reach item 0 from -1.
    if (_focusedIndex < 0) _focusedIndex = 0;
    _rebuildActionLists();
    if (widget.channels.isEmpty && widget.playlists != null) {
      final idx = widget.activePlaylistIndex;
      final list = widget.playlists!;
      if (idx >= 0 && idx < list.length) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          widget.onRefreshPlaylist?.call(list[idx]);
        });
      }
    }
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // Re-evaluate _focusedIndex after first frame when channels are confirmed.
      // initState runs before the widget tree renders so _filtered may be empty.
      final cur = _currentFilteredIndex;
      if (cur >= 0 && cur != _focusedIndex) {
        _focusedIndex = cur;
      }
      _checkScroll();
      // Schedule scroll on the *next* post-frame callback so the ListView has
      // had time to attach to the ScrollController (_sc.hasClients = true).
      // A single postFrameCallback is not enough — the ListView needs its own
      // layout pass before the ScrollController has a valid scroll position.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scrollToFocused();
      });
    });
    _sc.addListener(_checkScroll);
  }

  @override
  void didUpdateWidget(ChannelList oldWidget) {
    super.didUpdateWidget(oldWidget);
    // If we switched to a playlist with 0 channels, auto-refresh it
    if (widget.channels.isEmpty &&
        oldWidget.channels != widget.channels &&
        widget.playlists != null) {
      final idx  = widget.activePlaylistIndex;
      final list = widget.playlists!;
      if (idx >= 0 && idx < list.length) {
        WidgetsBinding.instance.addPostFrameCallback((_) {
          widget.onRefreshPlaylist?.call(list[idx]);
        });
      }
    }
  }

  void _checkScroll() {
    if (!_sc.hasClients) return;
    final atBottom = _sc.position.pixels >= _sc.position.maxScrollExtent - 10;
    final hasMore  = _sc.position.maxScrollExtent > 0;
    final show     = hasMore && !atBottom;
    if (show != _showMoreIndicator) setState(() => _showMoreIndicator = show);
  }

  void _scrollToCurrent() {
    if (!_sc.hasClients) return;
    final idx = _currentFilteredIndex;
    if (idx < 0) return;
    final itemHeight = widget.tvMode ? 72.0 : 48.0;
    final target     = idx * itemHeight;
    final viewHeight = _sc.position.viewportDimension;
    final maxExt     = _sc.position.maxScrollExtent;
    if (maxExt <= 0) return;
    final offset = (target - viewHeight / 2 + itemHeight / 2)
        .clamp(0.0, maxExt);
    _sc.animateTo(offset,
        duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _sc.removeListener(_checkScroll);
    if (_ownsController) _sc.dispose();
    _searchCtrl.dispose();
    _ownedListFocus?.dispose();
    super.dispose();
  }

  // ── Navigation within filtered list ───────────────────────────────────────

  /// Scroll so that [_focusedIndex] is centred in the viewport.
  /// Uses jumpTo (instant) so there is no lag when navigating with keys.
  void _scrollToFocused() {
    if (!_sc.hasClients) return;
    final list = _filtered;
    if (_focusedIndex < 0 || _focusedIndex >= list.length) return;
    final itemHeight = widget.tvMode ? 72.0 : 48.0;
    final target     = _focusedIndex * itemHeight;
    final viewHeight = _sc.position.viewportDimension;
    final maxExt     = _sc.position.maxScrollExtent;
    if (maxExt <= 0) return;
    final offset = (target - viewHeight / 2 + itemHeight / 2).clamp(0.0, maxExt);
    // Skip if item is already fully visible
    final cur        = _sc.offset;
    final itemBottom = target + itemHeight;
    if (target >= cur && itemBottom <= cur + viewHeight) return;
    _sc.jumpTo(offset);
  }

  /// Rebuild header and bottom-bar action lists from current widget callbacks.
  void _rebuildActionLists() {
    final hasMult = (widget.playlists?.length ?? 0) > 1;
    _headerActions = [
      if (hasMult) () {
        final list = widget.playlists!;
        final idx  = widget.activePlaylistIndex;
        widget.onPlaylistChanged?.call(list[(idx - 1 + list.length) % list.length]);
      },
      () => widget.onClose?.call(),
      () {
        final list = widget.playlists;
        if (list != null && widget.activePlaylistIndex < list.length) {
          widget.onRefreshPlaylist?.call(list[widget.activePlaylistIndex]);
        }
      },
      if (hasMult) () {
        final list = widget.playlists!;
        final idx  = widget.activePlaylistIndex;
        widget.onPlaylistChanged?.call(list[(idx + 1) % list.length]);
      },
    ];
    _bottomBarActions = List.from(widget.bottomBarActions ?? []);
  }

  /// D-pad / keyboard handler — unified for all zones.
  KeyEventResult _onListKey(FocusNode node, KeyEvent event) {
    if (event is! KeyDownEvent && event is! KeyRepeatEvent) {
      return KeyEventResult.ignored;
    }
    final key  = event.logicalKey;
    final list = _filtered;

    // ── Back always closes ───────────────────────────────────────────────────
    if (key == LogicalKeyboardKey.escape ||
        key == LogicalKeyboardKey.goBack ||
        key == LogicalKeyboardKey.backspace) {
      widget.onBottomBarFocusChanged?.call(-1);
      widget.onBack?.call();
      return KeyEventResult.handled;
    }

    // ── Enter / Select ───────────────────────────────────────────────────────
    if (key == LogicalKeyboardKey.enter ||
        key == LogicalKeyboardKey.select ||
        key == LogicalKeyboardKey.numpadEnter) {
      if (_zone == _FocusZone.list &&
          _focusedIndex >= 0 && _focusedIndex < list.length) {
        final ch      = list[_focusedIndex];
        final origIdx = widget.channels.indexOf(ch);
        widget.onTap(ch, origIdx);
      } else if (_zone == _FocusZone.header &&
          _headerFocusIdx < _headerActions.length) {
        _headerActions[_headerFocusIdx]();
      } else if (_zone == _FocusZone.bottomBar &&
          _bottomBarFocusIdx < _bottomBarActions.length) {
        _bottomBarActions[_bottomBarFocusIdx]();
      }
      return KeyEventResult.handled;
    }

    // ── Down ─────────────────────────────────────────────────────────────────
    if (key == LogicalKeyboardKey.arrowDown) {
      if (_zone == _FocusZone.header) {
        // Down from header → enter list at the dpad-focused index (not top)
        setState(() { _zone = _FocusZone.list; });
        _scrollToFocused();
      } else if (_zone == _FocusZone.bottomBar) {
        // Down from bottomBar → wrap around to header
        _rebuildActionLists();
        setState(() {
          _zone = _FocusZone.header;
          _headerFocusIdx = 0;
        });
        widget.onBottomBarFocusChanged?.call(-1);
      } else {
        if (list.isEmpty) return KeyEventResult.handled;
        setState(() {
          _focusedIndex = (_focusedIndex + 1).clamp(0, list.length - 1);
        });
        _scrollToFocused();
      }
      return KeyEventResult.handled;
    }

    // ── Up ───────────────────────────────────────────────────────────────────
    if (key == LogicalKeyboardKey.arrowUp) {
      if (_zone == _FocusZone.list && _focusedIndex <= 0) {
        // At top of list → move to header zone
        setState(() { _zone = _FocusZone.header; _headerFocusIdx = 0; });
      } else if (_zone == _FocusZone.bottomBar) {
        // Up from bottomBar → enter list at dpad-focused index (not bottom)
        setState(() { _zone = _FocusZone.list; });
        widget.onBottomBarFocusChanged?.call(-1);
        _scrollToFocused();
      } else if (_zone == _FocusZone.header) {
        // Up from header → wrap to bottomBar, rightmost button
        _rebuildActionLists();
        setState(() {
          _zone = _FocusZone.bottomBar;
          _bottomBarFocusIdx = (_bottomBarActions.length - 1).clamp(0, 99);
        });
        widget.onBottomBarFocusChanged?.call(_bottomBarFocusIdx);
      } else {
        if (list.isEmpty) return KeyEventResult.handled;
        setState(() {
          _focusedIndex = (_focusedIndex - 1).clamp(0, list.length - 1);
        });
        _scrollToFocused();
      }
      return KeyEventResult.handled;
    }

    // ── Left ─────────────────────────────────────────────────────────────────
    if (key == LogicalKeyboardKey.arrowLeft) {
      switch (_zone) {
        case _FocusZone.list:
          // Enter header zone at rightmost button
          _rebuildActionLists();
          setState(() {
            _zone = _FocusZone.header;
            _headerFocusIdx = (_headerActions.length - 1).clamp(0, 99);
          });
        case _FocusZone.header:
          if (_headerFocusIdx > 0) {
            // Move left within header
            setState(() => _headerFocusIdx--);
          } else {
            // Already at leftmost header button → wrap to bottomBar rightmost
            _rebuildActionLists();
            setState(() {
              _zone = _FocusZone.bottomBar;
              _bottomBarFocusIdx = (_bottomBarActions.length - 1).clamp(0, 99);
            });
            widget.onBottomBarFocusChanged?.call(_bottomBarFocusIdx);
          }
        case _FocusZone.bottomBar:
          if (_bottomBarFocusIdx > 0) {
            // Move left within bottomBar
            setState(() => _bottomBarFocusIdx--);
            widget.onBottomBarFocusChanged?.call(_bottomBarFocusIdx);
          } else {
            // Already at leftmost bottom bar → go to list (dpad focused item)
            setState(() { _zone = _FocusZone.list; });
            widget.onBottomBarFocusChanged?.call(-1);
            _scrollToFocused();
          }
      }
      return KeyEventResult.handled;
    }

    // ── Right ────────────────────────────────────────────────────────────────
    if (key == LogicalKeyboardKey.arrowRight) {
      switch (_zone) {
        case _FocusZone.list:
          // Enter bottom bar zone at first button
          _rebuildActionLists();
          setState(() { _zone = _FocusZone.bottomBar; _bottomBarFocusIdx = 0; });
          widget.onBottomBarFocusChanged?.call(0);
        case _FocusZone.bottomBar:
          if (_bottomBarFocusIdx < _bottomBarActions.length - 1) {
            // Move right within bottomBar
            setState(() => _bottomBarFocusIdx++);
            widget.onBottomBarFocusChanged?.call(_bottomBarFocusIdx);
          } else {
            // Already at rightmost → wrap to header leftmost
            _rebuildActionLists();
            setState(() {
              _zone = _FocusZone.header;
              _headerFocusIdx = 0;
            });
            widget.onBottomBarFocusChanged?.call(-1);
          }
        case _FocusZone.header:
          if (_headerFocusIdx < _headerActions.length - 1) {
            // Move right within header
            setState(() => _headerFocusIdx++);
          } else {
            // Already at rightmost header → enter list zone
            setState(() { _zone = _FocusZone.list; });
          }
      }
      return KeyEventResult.handled;
    }

    return KeyEventResult.ignored;
  }

  void _goNext() {
    final list = _filtered;
    if (list.isEmpty) return;
    final cur  = _currentFilteredIndex;
    final next = (cur + 1) % list.length;
    final ch   = list[next];
    widget.onTap(ch, widget.channels.indexOf(ch));
  }

  void _goPrev() {
    final list = _filtered;
    if (list.isEmpty) return;
    final cur  = _currentFilteredIndex;
    final prev = (cur - 1 + list.length) % list.length;
    final ch   = list[prev];
    widget.onTap(ch, widget.channels.indexOf(ch));
  }

  // ── Save search ────────────────────────────────────────────────────────────

  void _saveSearch() {
    final filtered = _filtered;
    if (filtered.isEmpty || _searchTerm.isEmpty) return;
    widget.onSaveSearch?.call(_searchTerm, filtered);
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final list        = _filtered;
    final hasSearch   = _searchTerm.isNotEmpty;
    final canSave     = hasSearch && list.isNotEmpty && widget.onSaveSearch != null;

    return Column(
      children: [
        // ── Playlist selector ─────────────────────────────────────────────
        _PlaylistSelectorRow(
          playlists:           widget.playlists,
          activeIndex:         widget.activePlaylistIndex,
          onPlaylistChanged:   widget.onPlaylistChanged,
          onRefreshPlaylist:   widget.onRefreshPlaylist,
          onClose:             widget.onClose,
          tvMode:              widget.tvMode,
          focusedBtnIndex:     _zone == _FocusZone.header ? _headerFocusIdx : -1,
        ),

        // ── Search row ────────────────────────────────────────────────────
        Container(
          color: Colors.black,
          padding: const EdgeInsets.fromLTRB(10, 6, 10, 0),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchCtrl,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  cursorColor: Colors.blue,
                  decoration: InputDecoration(
                    hintText: 'Search channels…',
                    hintStyle:
                        const TextStyle(color: Colors.white38, fontSize: 14),
                    prefixIcon: const Icon(Icons.search,
                        color: Colors.white38, size: 20),
                    suffixIcon: hasSearch
                        ? IconButton(
                            icon: const Icon(Icons.clear,
                                color: Colors.white38, size: 18),
                            onPressed: () => _searchCtrl.clear(),
                          )
                        : null,
                    isDense:  true,
                    filled:   true,
                    fillColor: Colors.white10,
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 8),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              // Save search button — only visible when there are results
              if (canSave) ...[
                const SizedBox(width: 6),
                Tooltip(
                  message: 'Save search as playlist',
                  child: InkWell(
                    onTap: _saveSearch,
                    borderRadius: BorderRadius.circular(8),
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.blue.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.playlist_add,
                          color: Colors.blue, size: 22),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),

        // Search result count + navigation hint
        if (hasSearch)
          Container(
            color: Colors.black,
            padding: const EdgeInsets.fromLTRB(14, 2, 14, 4),
            child: Row(
              children: [
                Text(
                  '${list.length} channel${list.length == 1 ? '' : 's'} found',
                  style: const TextStyle(
                      color: Colors.white38, fontSize: 11),
                ),
                const Spacer(),
                if (list.length > 1)
                  Text(
                    'swipe up/down to navigate filtered',
                    style: const TextStyle(
                        color: Colors.white24, fontSize: 10),
                  ),
              ],
            ),
          ),

        // ── Channel list ──────────────────────────────────────────────────
        Expanded(
          child: Stack(
            children: [
              Focus(
                focusNode: _listFocus,
                onKeyEvent: _onListKey,
                child: Container(
                  color: Colors.black87,
                  child: list.isEmpty
                      ? Center(
                          child: Text(
                            hasSearch
                                ? 'No channels match "$_searchTerm"'
                                : 'No channels',
                            style: const TextStyle(
                                color: Colors.white38, fontSize: 14),
                          ),
                        )
                      : ListView.builder(
                          controller: _sc,
                          itemCount: list.length,
                          itemBuilder: (context, i) {
                            final ch      = list[i];
                            final origIdx = widget.channels.indexOf(ch);
                            final selected    = ch.id == widget.currentChannelId;
                            final dpadFocused = i == _focusedIndex;
                            // listHasFocus: true only when the D-pad cursor is
                            // actively in the list zone. When in header/bottomBar,
                            // both highlights show as outlines so users can see
                            // that key input is directed elsewhere.
                            final listHasFocus = _zone == _FocusZone.list;
                            return _ChannelTile(
                              channel:      ch,
                              index:        origIdx,
                              filteredIndex: i,
                              selected:     selected,
                              dpadFocused:  dpadFocused,
                              listHasFocus: listHasFocus,
                              tvMode:       widget.tvMode,
                              showOrigIndex: !hasSearch,
                              onTap: () => widget.onTap(ch, origIdx),
                            );
                          },
                        ),
                ),
              ),
              if (_showMoreIndicator)
                Positioned(
                  bottom: 0, left: 0, right: 0,
                  child: Container(
                    height: 36,
                    color: Colors.black,
                    child: const Center(
                      child: Icon(Icons.keyboard_double_arrow_down,
                          color: Colors.white38, size: 22),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// Playlist selector header row
// ─────────────────────────────────────────────────────────────────────────────

class _PlaylistSelectorRow extends StatelessWidget {
  final List<IptvPlaylist>? playlists;
  final int activeIndex;
  final void Function(IptvPlaylist)? onPlaylistChanged;
  final void Function(IptvPlaylist)? onRefreshPlaylist;
  final VoidCallback? onClose;
  final bool tvMode;
  /// When ≥ 0, that button index in the header is D-pad-focused.
  final int focusedBtnIndex;

  const _PlaylistSelectorRow({
    required this.playlists,
    required this.activeIndex,
    required this.onPlaylistChanged,
    required this.onRefreshPlaylist,
    required this.tvMode,
    this.onClose,
    this.focusedBtnIndex = -1,
  });

  @override
  Widget build(BuildContext context) {
    final list = playlists;
    if (list == null || list.isEmpty) return const SizedBox.shrink();

    final hasMultiple = list.length > 1;
    final idx         = (activeIndex >= 0 && activeIndex < list.length)
        ? activeIndex : 0;
    final current     = list[idx];
    final count       = list.length;
    final channelCount = current.channels.length;
    final fs          = tvMode ? 15.0 : 13.0;
    const col         = Colors.white70;

    void goPrev() {
      if (!hasMultiple) return;
      onPlaylistChanged?.call(list[(idx - 1 + count) % count]);
    }

    void goNext() {
      if (!hasMultiple) return;
      onPlaylistChanged?.call(list[(idx + 1) % count]);
    }

    return Container(
      color: Colors.black,
      padding: EdgeInsets.symmetric(
          horizontal: 2, vertical: tvMode ? 6 : 3),
      child: Row(
        children: [
          // ◀ prev  (headerBtn index 0 when hasMultiple)
          if (hasMultiple)
            _ArrowBtn(icon: Icons.chevron_left, onTap: goPrev,
                focused: focusedBtnIndex == 0),

          // ✕ close channel list  (index 0 if no multiple, else 1)
          _ArrowBtn(
            icon:  Icons.close,
            onTap: () => onClose?.call(),
            focused: focusedBtnIndex == (hasMultiple ? 1 : 0),
          ),

          // Centre label — tappable to open picker
          Expanded(
            child: GestureDetector(
              onTap: hasMultiple
                  ? () => _showPicker(context, list, idx)
                  : null,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 6, vertical: 4),
                decoration: hasMultiple
                    ? BoxDecoration(
                        color: Colors.white.withOpacity(0.06),
                        borderRadius: BorderRadius.circular(6),
                      )
                    : null,
                // Format: "1/5: PlaylistName (55)  ▾"
                child: Text.rich(
                  TextSpan(
                    style: TextStyle(
                        color: col, fontSize: fs),
                    children: [
                      if (hasMultiple)
                        TextSpan(text: '${idx + 1}/$count: '),
                      TextSpan(
                        text: current.name,
                        style: const TextStyle(
                            fontWeight: FontWeight.w600),
                      ),
                      TextSpan(text: ' ($channelCount)'),
                      if (hasMultiple)
                        const TextSpan(
                          text: '  ▾',
                          style: TextStyle(
                              color: Colors.white38),
                        ),
                    ],
                  ),
                  maxLines:  1,
                  overflow:  TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ),

          // 🔄 refresh icon  (index: hasMultiple ? 2 : 1)
          _ArrowBtn(
            icon:  Icons.refresh,
            onTap: () => onRefreshPlaylist?.call(current),
            focused: focusedBtnIndex == (hasMultiple ? 2 : 1),
          ),

          // ▶ next  (index: hasMultiple ? 3 : never shown)
          if (hasMultiple)
            _ArrowBtn(icon: Icons.chevron_right, onTap: goNext,
                focused: focusedBtnIndex == 3),
        ],
      ),
    );
  }

  void _showPicker(
      BuildContext context, List<IptvPlaylist> list, int currentIdx) {
    showModalBottomSheet(
      context:         context,
      backgroundColor: Colors.grey.shade900,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
      ),
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Container(
                width: 36, height: 4,
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const Text('Switch Playlist',
                style: TextStyle(
                    color: Colors.white54,
                    fontSize: 12,
                    letterSpacing: 1)),
            const SizedBox(height: 8),
            ...list.asMap().entries.map((entry) {
              final i      = entry.key;
              final p      = entry.value;
              final active = i == currentIdx;
              return ListTile(
                leading: Icon(Icons.playlist_play,
                    color: active ? Colors.blue : Colors.white38),
                title: Text(p.name,
                    style: TextStyle(
                      color:      active ? Colors.blue : Colors.white,
                      fontWeight: active
                          ? FontWeight.bold : FontWeight.normal,
                    )),
                subtitle: Text('${p.channels.length} channels',
                    style: const TextStyle(
                        color: Colors.white38, fontSize: 12)),
                trailing: active
                    ? const Icon(Icons.check,
                        color: Colors.blue, size: 18)
                    : null,
                onTap: () {
                  Navigator.pop(context);
                  if (!active) onPlaylistChanged?.call(p);
                },
              );
            }),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

class _ArrowBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool focused;
  const _ArrowBtn({required this.icon, required this.onTap, this.focused = false});

  @override
  Widget build(BuildContext context) => AnimatedContainer(
    duration: const Duration(milliseconds: 100),
    decoration: BoxDecoration(
      color: focused ? Colors.blue.withOpacity(0.30) : Colors.transparent,
      borderRadius: BorderRadius.circular(8),
      border: Border.all(
        color: focused ? Colors.blue : Colors.transparent,
        width: 1.5,
      ),
    ),
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        child: Icon(icon,
            color: focused ? Colors.white : Colors.white70, size: 24),
      ),
    ),
  );
}

// ─────────────────────────────────────────────────────────────────────────────

class _ChannelTile extends StatelessWidget {
  final Channel      channel;
  final int          index;        // original index in full list
  final int          filteredIndex; // index in current filtered list
  final bool         selected;
  final bool         dpadFocused;  // D-pad cursor is on this row
  final bool         listHasFocus; // true = list zone is active; false = header/bottomBar active
  final bool         tvMode;
  final bool         showOrigIndex;
  final VoidCallback onTap;

  const _ChannelTile({
    required this.channel,
    required this.index,
    required this.filteredIndex,
    required this.selected,
    required this.dpadFocused,
    required this.listHasFocus,
    required this.tvMode,
    required this.showOrigIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    // ── Colour logic ─────────────────────────────────────────────────────────
    // listHasFocus = true  → full colours (list is in command)
    // listHasFocus = false → outline only (header/bottomBar is in command)
    //
    //  State          | listHasFocus=true        | listHasFocus=false
    //  ───────────────┼──────────────────────────┼───────────────────────────
    //  selected+dpad  | blue fill + white border  | blue outline only
    //  selected only  | blue fill                 | blue outline only
    //  dpad only      | white fill + white border | white outline only
    //  neither        | transparent               | transparent

    // Colours:
    //   selected only   → blue  (dim when list unfocused)
    //   dpad only       → light yellow  (dim when list unfocused)
    //   selected + dpad → green  (dim when list unfocused)
    //   neither         → transparent
    final double intensity = listHasFocus ? 1.0 : 0.45;

    final Color bgColor;
    if (selected && dpadFocused) {
      // Overlap: green
      bgColor = const Color(0xFF4CAF50).withOpacity(0.45 * intensity);
    } else if (selected) {
      // Playing channel: blue
      bgColor = Colors.blue.withOpacity(0.38 * intensity);
    } else if (dpadFocused) {
      // D-pad cursor: light yellow
      bgColor = const Color(0xFFFFEE88).withOpacity(0.55 * intensity);
    } else {
      bgColor = Colors.transparent;
    }

    // No borders/outlines — colour fills only, no lines.
    // selected = blue, dpadFocused = light yellow, overlap = green.
    // When list is unfocused (header/bottomBar active), fills become dim.
    Border? border; // always null — kept for BoxDecoration compatibility

    final BoxDecoration decoration = border != null
        ? BoxDecoration(color: bgColor, border: border)
        : BoxDecoration(color: bgColor);

    return Focus(
      autofocus: selected && tvMode,
      child: Container(
        decoration: decoration,
        child: ListTile(
          tileColor:         Colors.transparent,
          selected:          selected,
          selectedTileColor: Colors.transparent,
        dense:             !tvMode,
        leading: SizedBox(
          width: 40, height: 40,
          child: channel.logoUrl != null && channel.logoUrl!.isNotEmpty
              ? Image.network(channel.logoUrl!, fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) =>
                      const Icon(Icons.tv, color: Colors.white54))
              : const Icon(Icons.tv, color: Colors.white54),
        ),
        title: Text(
          channel.name,
          style: TextStyle(
            color:      Colors.white,
            fontSize:   tvMode ? 18 : 14,
            fontWeight: (selected || dpadFocused) ? FontWeight.bold : FontWeight.normal,
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: channel.isEncrypted
            ? Text(
                'ClearKey${channel.clearKeys.length > 1 ? " (${channel.clearKeys.length} keys)" : ""}',
                style: const TextStyle(color: Colors.orange, fontSize: 11))
            : null,
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (channel.isEncrypted)
              const Icon(Icons.key, color: Colors.orange, size: 14),
            const SizedBox(width: 4),
            // When searching show original channel number in brackets
            Text(
              showOrigIndex
                  ? '${index + 1}'
                  : '#${index + 1}',
              style: const TextStyle(color: Colors.white38, fontSize: 12),
            ),
          ],
        ),
        onTap: onTap,
        ),
      ),
    );
  }
}
