// lib/models/playlist.dart
import 'channel.dart';

class IptvPlaylist {
  final String id;
  final String name;
  final String url;
  final List<Channel> channels;
  final DateTime? lastUpdated;

  const IptvPlaylist({
    required this.id,
    required this.name,
    required this.url,
    this.channels = const [],
    this.lastUpdated,
  });

  IptvPlaylist copyWith({
    String? id,
    String? name,
    String? url,
    List<Channel>? channels,
    DateTime? lastUpdated,
  }) =>
      IptvPlaylist(
        id: id ?? this.id,
        name: name ?? this.name,
        url: url ?? this.url,
        channels: channels ?? this.channels,
        lastUpdated: lastUpdated ?? this.lastUpdated,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'url': url,
        'channels': channels.map((c) => c.toJson()).toList(),
        if (lastUpdated != null) 'lastUpdated': lastUpdated!.toIso8601String(),
      };

  factory IptvPlaylist.fromJson(Map<String, dynamic> j) => IptvPlaylist(
        id: j['id'] as String,
        name: j['name'] as String,
        url: j['url'] as String,
        channels: (j['channels'] as List<dynamic>? ?? [])
            .map((c) => Channel.fromJson(c as Map<String, dynamic>))
            .toList(),
        lastUpdated: j['lastUpdated'] != null
            ? DateTime.parse(j['lastUpdated'] as String)
            : null,
      );
}
