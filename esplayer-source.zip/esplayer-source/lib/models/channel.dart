// lib/models/channel.dart

class ClearKeyEntry {
  final String keyId;
  final String key;
  const ClearKeyEntry({required this.keyId, required this.key});
  Map<String, dynamic> toJson() => {'keyId': keyId, 'key': key};
  factory ClearKeyEntry.fromJson(Map<String, dynamic> j) =>
      ClearKeyEntry(keyId: j['keyId'] as String, key: j['key'] as String);
}

class Channel {
  final String id;
  final String name;
  final String url;
  final String? logoUrl;
  final String? userAgent;
  final String? referrer;
  final List<ClearKeyEntry> clearKeys;

  const Channel({
    required this.id,
    required this.name,
    required this.url,
    this.logoUrl,
    this.userAgent,
    this.referrer,
    this.clearKeys = const [],
  });

  bool get isEncrypted => clearKeys.isNotEmpty;

  Map<String, String> get clearKeyMap =>
      {for (final e in clearKeys) e.keyId: e.key};

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'url': url,
        if (logoUrl != null) 'logoUrl': logoUrl,
        if (userAgent != null) 'userAgent': userAgent,
        if (referrer != null) 'referrer': referrer,
        'clearKeys': clearKeys.map((e) => e.toJson()).toList(),
      };

  factory Channel.fromJson(Map<String, dynamic> j) => Channel(
        id: j['id'] as String,
        name: j['name'] as String,
        url: j['url'] as String,
        logoUrl: j['logoUrl'] as String?,
        userAgent: j['userAgent'] as String?,
        referrer: j['referrer'] as String?,
        clearKeys: (j['clearKeys'] as List<dynamic>? ?? [])
            .map((e) => ClearKeyEntry.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}
